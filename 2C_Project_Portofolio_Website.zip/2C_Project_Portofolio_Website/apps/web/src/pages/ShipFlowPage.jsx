import React, { useRef, useEffect, useState } from 'react';

const SHIPFLOW_HTML = `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ShipFlow – Maritime Logistics Intelligence Platform</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Sora:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#070d1a;--surf:#0d1526;--surf2:#111d30;--surf3:#162035;--border:#1e2f4a;--border2:rgba(30,47,74,.6);
  --blue:#2563eb;--blue2:#1d4ed8;--blue-l:#3b82f6;--blue-xl:#60a5fa;
  --cyan:#06b6d4;--teal:#0d9488;--green:#10b981;--green2:#059669;
  --amber:#f59e0b;--orange:#f97316;--red:#ef4444;--purple:#8b5cf6;
  --text:#e2e8f0;--text2:#94a3b8;--text3:#4b5e7a;
  --sidebar-w:230px;
  --shadow:0 4px 20px rgba(0,0,0,0.4);
}
::-webkit-scrollbar{width:5px;height:5px}::-webkit-scrollbar-track{background:var(--surf)}::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
body{font-family:'Sora',system-ui,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;overflow:hidden}

/* ── SIDEBAR ── */
#sidebar{width:var(--sidebar-w);background:var(--surf);border-right:1px solid var(--border);display:flex;flex-direction:column;height:100vh;overflow-y:auto;flex-shrink:0;transition:.3s}
.sb-logo{padding:18px 16px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px}
.sb-logo-icon{width:34px;height:34px;background:linear-gradient(135deg,var(--blue),var(--cyan));border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}
.sb-logo .t1{font-size:14px;font-weight:800;color:var(--blue-xl);letter-spacing:.3px}
.sb-logo .t2{font-size:9.5px;color:var(--text3);margin-top:1px;font-weight:400}
.sb-nav{flex:1;padding:8px 0}
.sb-nav a{display:flex;align-items:center;gap:9px;padding:8px 16px;color:var(--text2);text-decoration:none;font-size:12px;border-left:3px solid transparent;transition:.15s;cursor:pointer}
.sb-nav a:hover{color:var(--text);background:var(--surf2)}
.sb-nav a.active{color:var(--blue-xl);background:rgba(37,99,235,.08);border-left-color:var(--blue);font-weight:600}
.sb-nav .ic{font-size:14px;width:18px;text-align:center;flex-shrink:0}
.sb-section{font-size:9px;text-transform:uppercase;letter-spacing:1.2px;color:var(--text3);padding:12px 16px 3px;font-weight:700}
.sb-footer{padding:10px 16px;border-top:1px solid var(--border);font-size:9.5px;color:var(--text3)}
.sb-status{display:flex;align-items:center;gap:6px;margin-bottom:4px}
.dot{width:6px;height:6px;border-radius:50%;background:var(--green);box-shadow:0 0 5px var(--green);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}

/* ── MAIN ── */
#main{flex:1;display:flex;flex-direction:column;overflow:hidden;height:100vh}
#topbar{background:var(--surf);border-bottom:1px solid var(--border);padding:0 20px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;height:52px;gap:12px}
#topbar .page-title{font-size:14px;font-weight:700;display:flex;align-items:center;gap:8px}
#topbar .breadcrumb{font-size:10.5px;color:var(--text3);margin-left:4px;font-weight:400}
.topbar-right{display:flex;align-items:center;gap:10px}
.tb-chip{font-size:10px;font-weight:700;padding:3px 9px;border-radius:5px;letter-spacing:.3px;text-transform:uppercase}
.tb-chip.live{background:rgba(16,185,129,.1);color:var(--green);border:1px solid rgba(16,185,129,.25)}
.tb-chip.blue{background:rgba(37,99,235,.1);color:var(--blue-xl);border:1px solid rgba(37,99,235,.25)}
.tb-date{font-size:10.5px;color:var(--text3);font-family:'JetBrains Mono',monospace}
.tb-btn{background:var(--surf2);border:1px solid var(--border);color:var(--text2);padding:5px 11px;border-radius:6px;font-size:11px;cursor:pointer;font-family:inherit;transition:.15s}
.tb-btn:hover{color:var(--text);border-color:var(--blue)}
#content{flex:1;overflow-y:auto;padding:18px 20px 30px}

/* ── SECTIONS ── */
.section{display:none}.section.active{display:block}

/* ── GRID ── */
.g2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.g3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.g5{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}
.g6{display:grid;grid-template-columns:repeat(6,1fr);gap:10px}
.g-map{display:grid;grid-template-columns:1fr 340px;gap:14px}
.g-sim{display:grid;grid-template-columns:380px 1fr;gap:14px}

/* ── CARD ── */
.card{background:var(--surf);border:1px solid var(--border);border-radius:10px;padding:14px;transition:.2s}
.card:hover{border-color:var(--border2);box-shadow:0 4px 20px rgba(0,0,0,.3)}
.card-title{font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:var(--text3);margin-bottom:11px;font-weight:700;display:flex;align-items:center;gap:6px}
.card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.card-header .card-title{margin-bottom:0}

/* ── KPI ── */
.kpi{background:var(--surf);border:1px solid var(--border);border-radius:10px;padding:14px 16px;transition:.2s;position:relative;overflow:hidden}
.kpi:hover{border-color:rgba(37,99,235,.3);transform:translateY(-1px);box-shadow:0 6px 24px rgba(0,0,0,.3)}
.kpi::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;border-radius:10px 10px 0 0}
.kpi.blue::before{background:linear-gradient(90deg,var(--blue),var(--cyan))}
.kpi.green::before{background:linear-gradient(90deg,var(--green),var(--teal))}
.kpi.amber::before{background:linear-gradient(90deg,var(--amber),var(--orange))}
.kpi.red::before{background:linear-gradient(90deg,var(--red),#f97316)}
.kpi.purple::before{background:linear-gradient(90deg,var(--purple),var(--cyan))}
.kpi-top{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:8px}
.kpi-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}
.kpi-icon.blue{background:rgba(37,99,235,.12)}
.kpi-icon.green{background:rgba(16,185,129,.12)}
.kpi-icon.amber{background:rgba(245,158,11,.12)}
.kpi-icon.red{background:rgba(239,68,68,.12)}
.kpi-icon.purple{background:rgba(139,92,246,.12)}
.kpi-label{font-size:10px;color:var(--text3);font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px}
.kpi-value{font-size:26px;font-weight:800;line-height:1.1;font-family:'JetBrains Mono',monospace}
.kpi-sub{font-size:10px;color:var(--text3);margin-top:4px;display:flex;align-items:center;gap:5px}
.kpi-delta{font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px}
.kpi-delta.up{background:rgba(16,185,129,.1);color:var(--green)}
.kpi-delta.dn{background:rgba(239,68,68,.1);color:var(--red)}
.kpi-progress{height:3px;background:var(--surf2);border-radius:2px;margin-top:8px;overflow:hidden}
.kpi-pf{height:100%;border-radius:2px;transition:.5s}

/* ── STATUS ── */
.status{display:inline-flex;align-items:center;gap:4px;font-size:9px;font-weight:700;padding:2px 7px;border-radius:4px;text-transform:uppercase;letter-spacing:.4px}
.status.ok,.status.sailing{background:rgba(16,185,129,.12);color:var(--green)}
.status.warn,.status.waiting{background:rgba(245,158,11,.12);color:var(--amber)}
.status.crit,.status.delayed{background:rgba(239,68,68,.12);color:var(--red)}
.status.info,.status.loading{background:rgba(37,99,235,.12);color:var(--blue-xl)}
.status.neu,.status.maintenance{background:rgba(139,92,246,.12);color:var(--purple)}
.status::before{content:'';width:5px;height:5px;border-radius:50%;background:currentColor}

/* ── TABLES ── */
.tbl{width:100%;border-collapse:collapse;font-size:11.5px}
.tbl th{background:var(--surf2);color:var(--text3);font-weight:600;padding:7px 10px;text-align:left;border-bottom:1px solid var(--border);font-size:10px;text-transform:uppercase;letter-spacing:.4px;white-space:nowrap}
.tbl td{padding:8px 10px;border-bottom:1px solid rgba(30,47,74,.4);vertical-align:middle}
.tbl tr:hover td{background:rgba(13,21,38,.5)}
.tbl .mono{font-family:'JetBrains Mono',monospace;font-size:11px}

/* ── INPUTS ── */
.fg label{display:block;font-size:10px;color:var(--text3);margin-bottom:3px;font-weight:600;text-transform:uppercase;letter-spacing:.4px}
.fg input,.fg select,.fg textarea{width:100%;background:var(--surf2);border:1px solid var(--border);color:var(--text);padding:7px 10px;border-radius:6px;font-size:12px;font-family:inherit;transition:.15s}
.fg input:focus,.fg select:focus{outline:none;border-color:var(--blue);box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.fr2{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px}
.fr3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:10px}
.fr1{margin-bottom:10px}

/* ── BUTTONS ── */
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;border:none;transition:.15s;font-family:inherit}
.btn-p{background:var(--blue);color:#fff}.btn-p:hover{background:var(--blue2)}
.btn-s{background:var(--surf2);color:var(--text);border:1px solid var(--border)}.btn-s:hover{background:var(--border)}
.btn-g{background:rgba(16,185,129,.12);color:var(--green);border:1px solid rgba(16,185,129,.25)}.btn-g:hover{background:rgba(16,185,129,.22)}
.btn-r{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}.btn-r:hover{background:rgba(239,68,68,.22)}
.btn-sm{padding:4px 9px;font-size:10.5px}
.btn-amber{background:rgba(245,158,11,.12);color:var(--amber);border:1px solid rgba(245,158,11,.25)}

/* ── CHARTS ── */
.ch{position:relative;height:200px}
.ch-lg{position:relative;height:260px}
.ch-xl{position:relative;height:320px}
.ch-sm{position:relative;height:140px}

/* ── ALERTS ── */
.alert{padding:10px 13px;border-radius:7px;font-size:11.5px;margin-bottom:8px;border-left:3px solid;display:flex;gap:10px;align-items:flex-start}
.alert .al-icon{font-size:15px;flex-shrink:0;margin-top:1px}
.alert.crit{background:rgba(239,68,68,.06);border-color:var(--red)}
.alert.warn{background:rgba(245,158,11,.06);border-color:var(--amber)}
.alert.ok{background:rgba(16,185,129,.06);border-color:var(--green)}
.alert.info{background:rgba(37,99,235,.06);border-color:var(--blue)}
.alert.opp{background:rgba(139,92,246,.06);border-color:var(--purple)}
.alert strong{font-weight:700;display:block;margin-bottom:2px;font-size:12px}
.alert .al-tag{font-size:9px;font-weight:700;padding:1px 6px;border-radius:3px;text-transform:uppercase;letter-spacing:.4px;display:inline-block;margin-top:3px}
.alert.crit .al-tag{background:rgba(239,68,68,.15);color:var(--red)}
.alert.warn .al-tag{background:rgba(245,158,11,.15);color:var(--amber)}
.alert.ok .al-tag{background:rgba(16,185,129,.15);color:var(--green)}
.alert.info .al-tag{background:rgba(37,99,235,.15);color:var(--blue-xl)}
.alert.opp .al-tag{background:rgba(139,92,246,.15);color:var(--purple)}

/* ── SECTION HEADER ── */
.shdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.shdr h2{font-size:17px;font-weight:700;display:flex;align-items:center;gap:8px}
.shdr .sub{font-size:11px;color:var(--text3);margin-top:2px}

/* ── VESSEL CARD ── */
.vessel-card{background:var(--surf);border:1px solid var(--border);border-radius:10px;padding:14px;transition:.2s;cursor:pointer}
.vessel-card:hover{border-color:rgba(37,99,235,.3);box-shadow:0 4px 20px rgba(0,0,0,.3)}
.vc-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px}
.vc-name{font-size:13px;font-weight:700;margin-bottom:2px}
.vc-imo{font-size:9.5px;color:var(--text3);font-family:'JetBrains Mono',monospace}
.vc-stats{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.vc-stat label{font-size:9px;color:var(--text3);text-transform:uppercase;letter-spacing:.4px;display:block;margin-bottom:1px}
.vc-stat span{font-size:12px;font-weight:600;font-family:'JetBrains Mono',monospace}

/* ── WORLD MAP ── */
.map-container{background:var(--surf);border:1px solid var(--border);border-radius:10px;overflow:hidden;position:relative}
.map-canvas{background:linear-gradient(180deg,#050e1f 0%,#071323 40%,#050e1f 100%);width:100%;height:420px;position:relative;overflow:hidden}
.map-grid{position:absolute;inset:0;opacity:.06;background-image:linear-gradient(rgba(37,99,235,.5) 1px,transparent 1px),linear-gradient(90deg,rgba(37,99,235,.5) 1px,transparent 1px);background-size:40px 40px}
.map-graticule{position:absolute;inset:0;opacity:.04;background-image:linear-gradient(rgba(6,182,212,.6) 1px,transparent 1px),linear-gradient(90deg,rgba(6,182,212,.6) 1px,transparent 1px);background-size:80px 60px}
.map-continent{position:absolute;border-radius:6px;opacity:.25}
.vessel-dot{position:absolute;width:10px;height:10px;border-radius:50%;cursor:pointer;transform:translate(-50%,-50%);transition:.2s;z-index:10}
.vessel-dot::after{content:'';position:absolute;inset:-4px;border-radius:50%;animation:sonar 2s infinite;opacity:.3}
.vessel-dot.sailing{background:var(--green)}.vessel-dot.sailing::after{background:var(--green)}
.vessel-dot.loading{background:var(--blue-xl)}.vessel-dot.loading::after{background:var(--blue-xl)}
.vessel-dot.waiting{background:var(--amber)}.vessel-dot.waiting::after{background:var(--amber)}
.vessel-dot.delayed{background:var(--red)}.vessel-dot.delayed::after{background:var(--red)}
.vessel-dot.maintenance{background:var(--purple)}.vessel-dot.maintenance::after{background:var(--purple)}
@keyframes sonar{0%{transform:scale(1);opacity:.4}100%{transform:scale(2.5);opacity:0}}
.vessel-tooltip{position:absolute;background:var(--surf);border:1px solid var(--border);border-radius:8px;padding:10px 12px;font-size:11px;z-index:20;pointer-events:none;white-space:nowrap;box-shadow:var(--shadow);display:none}
.vessel-tooltip.visible{display:block}
.route-svg{position:absolute;inset:0;pointer-events:none}
.port-marker{position:absolute;transform:translate(-50%,-50%);z-index:8}
.port-dot{width:7px;height:7px;background:var(--cyan);border-radius:50%;border:1.5px solid rgba(6,182,212,.5);box-shadow:0 0 8px rgba(6,182,212,.4)}
.port-label{font-size:9px;color:var(--cyan);white-space:nowrap;margin-top:3px;font-weight:600;text-align:center;font-family:'JetBrains Mono',monospace}
.map-legend{position:absolute;bottom:12px;left:12px;background:rgba(7,13,26,.85);border:1px solid var(--border);border-radius:8px;padding:9px 12px;font-size:10px;display:flex;gap:12px;flex-wrap:wrap}
.ml-item{display:flex;align-items:center;gap:5px;color:var(--text2)}
.ml-dot{width:8px;height:8px;border-radius:50%}
.map-toolbar{background:var(--surf2);border-bottom:1px solid var(--border);padding:8px 14px;display:flex;align-items:center;gap:10px;font-size:11px}

/* ── PROGRESS ── */
.prog{height:6px;background:var(--surf2);border-radius:3px;overflow:hidden}
.prog-f{height:100%;border-radius:3px;transition:.5s}

/* ── ROUTE CARD ── */
.route-opt{background:var(--surf2);border:1px solid var(--border);border-radius:8px;padding:12px 14px;margin-bottom:8px;cursor:pointer;transition:.15s}
.route-opt:hover{border-color:rgba(37,99,235,.3)}
.route-opt.selected{border-color:var(--blue);background:rgba(37,99,235,.06)}
.ro-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.ro-label{font-size:12px;font-weight:700}
.ro-savings{display:flex;gap:10px;flex-wrap:wrap}
.ro-save-item{text-align:center;flex:1;min-width:70px}
.ro-save-item .val{font-size:16px;font-weight:800;color:var(--green);font-family:'JetBrains Mono',monospace}
.ro-save-item .lbl{font-size:9.5px;color:var(--text3);margin-top:1px}

/* ── PORT GAUGE ── */
.port-gauge{text-align:center;padding:8px}
.gauge-val{font-size:28px;font-weight:800;font-family:'JetBrains Mono',monospace}
.gauge-lbl{font-size:10px;color:var(--text3);margin-top:3px}

/* ── DIVIDER ── */
.div{border:none;border-top:1px solid var(--border);margin:12px 0}
.sep{font-size:9.5px;color:var(--text3);font-weight:700;padding:8px 0;border-bottom:1px solid var(--border);margin-bottom:10px;text-transform:uppercase;letter-spacing:.5px}

/* ── MISC ── */
.mono{font-family:'JetBrains Mono',monospace}
.flex{display:flex;align-items:center}.btw{justify-content:space-between}.gap8{gap:8px}.gap12{gap:12px}.gap6{gap:6px}
.mb6{margin-bottom:6px}.mb8{margin-bottom:8px}.mb10{margin-bottom:10px}.mb12{margin-bottom:12px}.mb14{margin-bottom:14px}.mb16{margin-bottom:16px}
.mt8{margin-top:8px}.mt10{margin-top:10px}.mt12{margin-top:12px}
.text-green{color:var(--green)}.text-red{color:var(--red)}.text-amber{color:var(--amber)}.text-blue{color:var(--blue-xl)}.text-cyan{color:var(--cyan)}.text-purple{color:var(--purple)}
.fw7{font-weight:700}.fw8{font-weight:800}
.fs10{font-size:10px}.fs11{font-size:11px}.fs12{font-size:12px}.fs13{font-size:13px}
.text2{color:var(--text2)}.text3{color:var(--text3)}

/* ── AI CHAT ── */
.ai-chat{position:fixed;bottom:20px;right:20px;z-index:999}
.ai-toggle{width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,var(--blue),var(--cyan));border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:20px;box-shadow:0 4px 20px rgba(37,99,235,.4);transition:.2s}
.ai-toggle:hover{transform:scale(1.08)}
.ai-panel{position:absolute;bottom:56px;right:0;width:320px;background:var(--surf);border:1px solid var(--border);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.5);display:none;flex-direction:column;overflow:hidden;max-height:440px}
.ai-panel.open{display:flex}
.ai-head{background:linear-gradient(135deg,var(--blue),var(--cyan));padding:12px 14px;display:flex;align-items:center;gap:8px;flex-shrink:0}
.ai-head .ai-title{font-size:13px;font-weight:700;color:#fff}
.ai-head .ai-sub{font-size:9.5px;color:rgba(255,255,255,.7)}
.ai-msgs{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px}
.ai-msg{padding:8px 11px;border-radius:8px;font-size:11.5px;line-height:1.5}
.ai-msg.bot{background:var(--surf2);border:1px solid var(--border);align-self:flex-start;max-width:90%}
.ai-msg.user{background:rgba(37,99,235,.15);border:1px solid rgba(37,99,235,.25);align-self:flex-end;max-width:90%}
.ai-input-row{padding:10px;border-top:1px solid var(--border);display:flex;gap:6px;flex-shrink:0}
.ai-input-row input{flex:1;background:var(--surf2);border:1px solid var(--border);color:var(--text);padding:7px 10px;border-radius:6px;font-size:11.5px;font-family:inherit}
.ai-input-row input:focus{outline:none;border-color:var(--blue)}
.ai-send{background:var(--blue);border:none;color:#fff;width:32px;height:32px;border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;flex-shrink:0}

/* ── SUSTAINABILITY ── */
.esg-score{text-align:center;padding:16px}
.esg-num{font-size:56px;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1}
.esg-grade{font-size:14px;font-weight:700;margin-top:6px}
.cii-bar{height:12px;border-radius:6px;background:linear-gradient(90deg,var(--green),var(--amber) 50%,var(--red));margin:8px 0;position:relative;overflow:visible}
.cii-ptr{position:absolute;top:-5px;width:3px;height:22px;background:#fff;border-radius:2px;transform:translateX(-50%);box-shadow:0 0 6px rgba(255,255,255,.5);transition:.5s}

/* ── SCENARIO ── */
.sc-comp{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.sc-before{border:1px solid var(--border)}
.sc-after{border:1px solid var(--green)}
.sc-delta{display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;padding:3px 8px;border-radius:4px}
.sc-delta.pos{background:rgba(16,185,129,.1);color:var(--green)}
.sc-delta.neg{background:rgba(239,68,68,.1);color:var(--red)}

/* ── RESPONSIVE ── */
@media(max-width:1000px){#sidebar{display:none}#sidebar.open{display:flex;position:fixed;z-index:999;height:100vh}.g-map{grid-template-columns:1fr}.g-sim{grid-template-columns:1fr}.g4{grid-template-columns:1fr 1fr}.g3{grid-template-columns:1fr 1fr}.g6{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.g4,.g3,.g2,.g6{grid-template-columns:1fr}.fr2,.fr3{grid-template-columns:1fr}#content{padding:10px}}
</style>
</head>
<body>

<nav id="sidebar">
  <div class="sb-logo">
    <div class="sb-logo-icon">🚢</div>
    <div>
      <div class="t1">ShipFlow AI</div>
      <div class="t2">Maritime Intelligence v2.0</div>
    </div>
  </div>
  <div class="sb-nav">
    <div class="sb-section">Command</div>
    <a data-tab="dashboard" class="active"><span class="ic">📊</span>Executive Dashboard</a>
    <a data-tab="fleet"><span class="ic">🚢</span>Fleet Management</a>
    <a data-tab="voyage"><span class="ic">🗺️</span>Voyage Planning</a>

    <div class="sb-section">Operations</div>
    <a data-tab="port"><span class="ic">⚓</span>Port Operations</a>
    <a data-tab="cargo"><span class="ic">📦</span>Cargo Management</a>
    <a data-tab="route"><span class="ic">🧭</span>Route Optimization</a>
    <a data-tab="delay"><span class="ic">⏱️</span>Delay Analytics</a>

    <div class="sb-section">Finance & ESG</div>
    <a data-tab="fuel"><span class="ic">⛽</span>Fuel Management</a>
    <a data-tab="cost"><span class="ic">💰</span>Cost Intelligence</a>
    <a data-tab="esg"><span class="ic">🌱</span>Sustainability</a>

    <div class="sb-section">Intelligence</div>
    <a data-tab="scenario"><span class="ic">🔮</span>Scenario Simulation</a>
    <a data-tab="report"><span class="ic">📑</span>Reports Center</a>
  </div>
  <div class="sb-footer">
    <div class="sb-status"><div class="dot"></div><span>System Live · AIS Connected</span></div>
    <div>Fastabiq Rahmat Imanu</div>
  </div>
</nav>

<div id="main">
  <div id="topbar">
    <div class="page-title">
      <span>📊</span>
      <span id="topbar-title">Executive Dashboard</span>
      <span class="breadcrumb" id="topbar-bc">/ Overview</span>
    </div>
    <div class="topbar-right">
      <span class="tb-chip live">● Live</span>
      <span class="tb-chip blue">AIS Active</span>
      <span class="tb-date" id="topbar-date">--</span>
      <button class="tb-btn" onclick="toggleSidebar()">☰</button>
      <button class="tb-btn btn-p btn-sm" onclick="exportReport()">⬇ Export</button>
    </div>
  </div>

  <div id="content">

    <div id="tab-dashboard" class="section active">
      <div class="shdr">
        <div><h2>📊 Executive Dashboard</h2><div class="sub">Real-time fleet overview · Last updated <span id="last-update">just now</span></div></div>
        <div class="flex gap8">
          <button class="btn btn-s btn-sm">↻ Refresh</button>
          <button class="btn btn-p btn-sm">📤 Share</button>
        </div>
      </div>

      <div class="g5 mb14">
        <div class="kpi blue">
          <div class="kpi-top">
            <div><div class="kpi-label">Active Vessels</div><div class="kpi-value text-blue" id="kpi-vessels">42</div></div>
            <div class="kpi-icon blue">🚢</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta up">↑ 3</span> vs last month</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:84%;background:var(--blue)"></div></div>
        </div>
        <div class="kpi green">
          <div class="kpi-top">
            <div><div class="kpi-label">Cargo Delivered</div><div class="kpi-value text-green" id="kpi-cargo">2.4M</div></div>
            <div class="kpi-icon green">📦</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta up">↑ 8.2%</span> TEU this month</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:78%;background:var(--green)"></div></div>
        </div>
        <div class="kpi amber">
          <div class="kpi-top">
            <div><div class="kpi-label">Avg Voyage Time</div><div class="kpi-value text-amber" id="kpi-voyage">18.4d</div></div>
            <div class="kpi-icon amber">⏱️</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta dn">↑ 0.6d</span> vs target 17.8d</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:72%;background:var(--amber)"></div></div>
        </div>
        <div class="kpi blue">
          <div class="kpi-top">
            <div><div class="kpi-label">Fleet Utilization</div><div class="kpi-value text-blue" id="kpi-util">87.3%</div></div>
            <div class="kpi-icon blue">📈</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta up">↑ 2.1%</span> target 90%</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:87%;background:var(--blue-l)"></div></div>
        </div>
        <div class="kpi green">
          <div class="kpi-top">
            <div><div class="kpi-label">On-Time Arrival</div><div class="kpi-value text-green" id="kpi-ota">78.5%</div></div>
            <div class="kpi-icon green">✅</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta dn">↓ 1.4%</span> target 85%</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:78%;background:var(--green)"></div></div>
        </div>
      </div>

      <div class="g5 mb14">
        <div class="kpi red">
          <div class="kpi-top">
            <div><div class="kpi-label">Fuel Consumption</div><div class="kpi-value text-red" id="kpi-fuel">4,820</div></div>
            <div class="kpi-icon red">⛽</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta dn">↑ 3.4%</span> MT/day avg</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:62%;background:var(--red)"></div></div>
        </div>
        <div class="kpi amber">
          <div class="kpi-top">
            <div><div class="kpi-label">CO₂ Emissions</div><div class="kpi-value text-amber" id="kpi-co2">14.8k</div></div>
            <div class="kpi-icon amber">🌫️</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta dn">↑ 2.1%</span> tCO₂/month</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:55%;background:var(--orange)"></div></div>
        </div>
        <div class="kpi green">
          <div class="kpi-top">
            <div><div class="kpi-label">Revenue</div><div class="kpi-value text-green" id="kpi-rev">$84.2M</div></div>
            <div class="kpi-icon green">💵</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta up">↑ 11.3%</span> this month</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:92%;background:var(--green)"></div></div>
        </div>
        <div class="kpi blue">
          <div class="kpi-top">
            <div><div class="kpi-label">Cost per Voyage</div><div class="kpi-value text-blue" id="kpi-cpv">$342K</div></div>
            <div class="kpi-icon blue">💸</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta up">↓ 4.2%</span> optimized</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:68%;background:var(--cyan)"></div></div>
        </div>
        <div class="kpi amber">
          <div class="kpi-top">
            <div><div class="kpi-label">Port Turnaround</div><div class="kpi-value text-amber" id="kpi-tat">22.4h</div></div>
            <div class="kpi-icon amber">⚓</div>
          </div>
          <div class="kpi-sub"><span class="kpi-delta dn">↑ 1.2h</span> target 20h</div>
          <div class="kpi-progress"><div class="kpi-pf" style="width:60%;background:var(--amber)"></div></div>
        </div>
      </div>

      <div class="g-map mb14">
        <div class="map-container">
          <div class="map-toolbar">
            <span class="fw7 fs11">🗺 Live Fleet Tracking</span>
            <span style="flex:1"></span>
            <span class="fs10 text2">42 vessels · 18 ports · 6 weather zones</span>
            <button class="btn btn-s btn-sm" style="margin-left:8px">Fullscreen</button>
          </div>
          <div class="map-canvas" id="main-map">
            <div class="map-grid"></div>
            <div class="map-graticule"></div>
            <div class="map-continent" style="left:18%;top:18%;width:12%;height:28%;background:rgba(30,100,60,.4);border-radius:40% 50% 30% 40%"></div>
            <div class="map-continent" style="left:42%;top:12%;width:20%;height:32%;background:rgba(40,80,50,.4);border-radius:50% 40% 50% 30%"></div>
            <div class="map-continent" style="left:63%;top:8%;width:14%;height:36%;background:rgba(30,90,55,.4);border-radius:40%"></div>
            <div class="map-continent" style="left:10%;top:45%;width:9%;height:30%;background:rgba(40,80,50,.35);border-radius:30%"></div>
            <div class="map-continent" style="left:62%;top:48%;width:12%;height:28%;background:rgba(35,90,50,.35);border-radius:40%"></div>
            <div class="map-continent" style="left:78%;top:48%;width:14%;height:25%;background:rgba(30,100,60,.3);border-radius:35%"></div>

            <svg class="route-svg" id="route-svg" viewBox="0 0 800 420" preserveAspectRatio="none">
              <defs>
                <marker id="arr" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
                  <path d="M0,0 L6,3 L0,6 Z" fill="rgba(37,99,235,.5)"/>
                </marker>
              </defs>
              <path d="M 140 160 Q 260 120 380 180 Q 500 240 620 200" stroke="rgba(37,99,235,.3)" stroke-width="1.5" fill="none" stroke-dasharray="6,4" marker-end="url(#arr)"/>
              <path d="M 200 200 Q 350 260 520 220 Q 620 200 700 240" stroke="rgba(6,182,212,.25)" stroke-width="1.5" fill="none" stroke-dasharray="6,4"/>
              <path d="M 380 180 Q 480 250 580 280 Q 660 300 720 340" stroke="rgba(16,185,129,.2)" stroke-width="1" fill="none" stroke-dasharray="4,4"/>
              <path d="M 520 220 Q 580 180 650 160 Q 700 150 740 170" stroke="rgba(245,158,11,.2)" stroke-width="1" fill="none" stroke-dasharray="4,4"/>
              <ellipse cx="500" cy="150" rx="50" ry="30" fill="rgba(239,68,68,.05)" stroke="rgba(239,68,68,.2)" stroke-width="1" stroke-dasharray="3,3"/>
              <text x="500" y="135" text-anchor="middle" fill="rgba(239,68,68,.5)" font-size="8">⚠ Storm</text>
            </svg>

            <div class="port-marker" style="left:17%;top:38%"><div class="port-dot"></div><div class="port-label">Rotterdam</div></div>
            <div class="port-marker" style="left:48%;top:42%"><div class="port-dot"></div><div class="port-label">Suez</div></div>
            <div class="port-marker" style="left:65%;top:52%"><div class="port-dot"></div><div class="port-label">Singapore</div></div>
            <div class="port-marker" style="left:76%;top:38%"><div class="port-dot"></div><div class="port-label">Shanghai</div></div>
            <div class="port-marker" style="left:12%;top:48%"><div class="port-dot"></div><div class="port-label">New York</div></div>
            <div class="port-marker" style="left:32%;top:58%"><div class="port-dot"></div><div class="port-label">Santos</div></div>
            <div class="port-marker" style="left:82%;top:62%"><div class="port-dot"></div><div class="port-label">Sydney</div></div>
            <div class="port-marker" style="left:54%;top:28%"><div class="port-dot"></div><div class="port-label">Dubai</div></div>

            <div class="vessel-dot sailing" style="left:28%;top:39%" title="MV Atlantic Star"></div>
            <div class="vessel-dot sailing" style="left:55%;top:45%" title="MV Pacific Glory"></div>
            <div class="vessel-dot loading" style="left:65%;top:52%" title="MV Singapore Express"></div>
            <div class="vessel-dot waiting" style="left:76%;top:38%" title="MV Shanghai King"></div>
            <div class="vessel-dot delayed" style="left:41%;top:37%" title="MV Arabian Sea"></div>
            <div class="vessel-dot sailing" style="left:68%;top:42%" title="MV Eastern Wind"></div>
            <div class="vessel-dot maintenance" style="left:17%;top:37%" title="MV Rotterdam Bay"></div>
            <div class="vessel-dot sailing" style="left:50%;top:52%" title="MV Indian Ocean"></div>
            <div class="vessel-dot sailing" style="left:22%;top:52%" title="MV South Atlantic"></div>
            <div class="vessel-dot loading" style="left:82%;top:62%" title="MV Sydney Cove"></div>

            <div class="map-legend">
              <div class="ml-item"><div class="ml-dot" style="background:var(--green)"></div>Sailing (28)</div>
              <div class="ml-item"><div class="ml-dot" style="background:var(--blue-xl)"></div>Loading (6)</div>
              <div class="ml-item"><div class="ml-dot" style="background:var(--amber)"></div>Waiting (4)</div>
              <div class="ml-item"><div class="ml-dot" style="background:var(--red)"></div>Delayed (3)</div>
              <div class="ml-item"><div class="ml-dot" style="background:var(--purple)"></div>Maint. (1)</div>
            </div>
          </div>
        </div>

        <div>
          <div class="card mb14" style="height:fit-content">
            <div class="card-title">🤖 AI Copilot Insights</div>
            <div class="alert crit">
              <span class="al-icon">🚨</span>
              <div><strong>Singapore Port Congestion</strong>Estimated +8h turnaround delay for 4 vessels in queue. Rerouting recommended.<span class="al-tag">CRITICAL</span></div>
            </div>
            <div class="alert opp">
              <span class="al-icon">💡</span>
              <div><strong>Route Optimization Opportunity</strong>Alternate route via Lombok Strait saves $14,200/voyage for Pacific routes.<span class="al-tag">OPPORTUNITY</span></div>
            </div>
            <div class="alert warn">
              <span class="al-icon">⚠️</span>
              <div><strong>Fuel Consumption Alert</strong>MV Eastern Wind consuming 12% above baseline. Engine check recommended.<span class="al-tag">WARNING</span></div>
            </div>
            <div class="alert info">
              <span class="al-icon">📡</span>
              <div><strong>Weather Advisory</strong>Typhoon risk in South China Sea. 3 vessels may need rerouting in 48h.<span class="al-tag">INFO</span></div>
            </div>
            <div class="alert ok">
              <span class="al-icon">✅</span>
              <div><strong>Fleet Utilization Improving</strong>Utilization up 2.1% this week. On track for Q4 targets.<span class="al-tag">INFO</span></div>
            </div>
          </div>

          <div class="card">
            <div class="card-title">📈 Fleet Status Summary</div>
            <div class="g2 mb10">
              <div style="text-align:center;padding:8px;background:var(--surf2);border-radius:8px">
                <div class="fw8 fs13 text-green">28</div><div class="fs10 text3">Sailing</div>
              </div>
              <div style="text-align:center;padding:8px;background:var(--surf2);border-radius:8px">
                <div class="fw8 fs13 text-blue">6</div><div class="fs10 text3">Loading</div>
              </div>
              <div style="text-align:center;padding:8px;background:var(--surf2);border-radius:8px">
                <div class="fw8 fs13 text-amber">4</div><div class="fs10 text3">Waiting</div>
              </div>
              <div style="text-align:center;padding:8px;background:var(--surf2);border-radius:8px">
                <div class="fw8 fs13 text-red">3</div><div class="fs10 text3">Delayed</div>
              </div>
            </div>
            <div class="ch-sm"><canvas id="ch-fleet-status"></canvas></div>
          </div>
        </div>
      </div>

      <div class="g3 mb14">
        <div class="card">
          <div class="card-title">📊 Monthly Revenue Trend</div>
          <div class="ch"><canvas id="ch-revenue"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">⛽ Fuel Cost Trend</div>
          <div class="ch"><canvas id="ch-fuel-trend"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">⏱ Voyage Duration Distribution</div>
          <div class="ch"><canvas id="ch-voyage-dist"></canvas></div>
        </div>
      </div>
    </div>

    <div id="tab-fleet" class="section">
      <div class="shdr mb14">
        <div><h2>🚢 Fleet Management</h2><div class="sub">42 vessels · Performance tracking & health monitoring</div></div>
        <div class="flex gap8">
          <button class="btn btn-s btn-sm">🔍 Filter</button>
          <button class="btn btn-p btn-sm">+ Add Vessel</button>
        </div>
      </div>

      <div class="g4 mb14">
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">Total Fleet</div><div class="kpi-value text-blue">42</div></div><div class="kpi-icon blue">🚢</div></div><div class="kpi-sub">DWT: 3.2M tonnes</div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">Avg Utilization</div><div class="kpi-value text-green">87.3%</div></div><div class="kpi-icon green">📊</div></div><div class="kpi-sub"><span class="kpi-delta up">↑ 2.1%</span></div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">Avg Speed</div><div class="kpi-value text-amber">14.8 kn</div></div><div class="kpi-icon amber">💨</div></div><div class="kpi-sub">Target: 15.5 kn</div></div>
        <div class="kpi red"><div class="kpi-top"><div><div class="kpi-label">Due Maintenance</div><div class="kpi-value text-red">4</div></div><div class="kpi-icon red">🔧</div></div><div class="kpi-sub">In next 30 days</div></div>
      </div>

      <div class="card mb14">
        <div class="card-header">
          <div class="card-title">🚢 Vessel Registry</div>
          <input style="width:200px;background:var(--surf2);border:1px solid var(--border);color:var(--text);padding:5px 9px;border-radius:6px;font-size:11px;font-family:inherit" placeholder="🔍 Search vessel...">
        </div>
        <div style="overflow-x:auto">
          <table class="tbl">
            <thead>
              <tr><th>Vessel Name</th><th>IMO</th><th>Type</th><th>Capacity</th><th>Position</th><th>Speed</th><th>Fuel (MT/d)</th><th>Util%</th><th>ETA</th><th>Health</th><th>Status</th></tr>
            </thead>
            <tbody id="fleet-tbody"></tbody>
          </table>
        </div>
      </div>

      <div class="g2">
        <div class="card">
          <div class="card-title">📊 Fleet Utilization by Vessel Type</div>
          <div class="ch"><canvas id="ch-fleet-util"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">🏆 Top Performing Vessels</div>
          <div id="top-vessels"></div>
        </div>
      </div>
    </div>

    <div id="tab-voyage" class="section">
      <div class="shdr mb14">
        <div><h2>🗺️ Voyage Planning</h2><div class="sub">Voyage simulation engine · Cost & performance calculator</div></div>
      </div>
      <div class="g-sim">
        <div>
          <div class="card mb14">
            <div class="card-title">⚙️ Voyage Parameters</div>
            <div class="fr2">
              <div class="fg"><label>Origin Port</label>
                <select id="vp-origin"><option>Rotterdam (NLRTM)</option><option>Singapore (SGSIN)</option><option>Shanghai (CNSHA)</option><option>Dubai (AEJEA)</option><option>Los Angeles (USLAX)</option><option>New York (USNYC)</option></select>
              </div>
              <div class="fg"><label>Destination Port</label>
                <select id="vp-dest"><option>Singapore (SGSIN)</option><option>Rotterdam (NLRTM)</option><option>Shanghai (CNSHA)</option><option>Dubai (AEJEA)</option><option>Los Angeles (USLAX)</option><option>Sydney (AUSYD)</option></select>
              </div>
            </div>
            <div class="fr3">
              <div class="fg"><label>Distance (nm)</label><input type="number" id="vp-dist" value="10843" min="100"></div>
              <div class="fg"><label>Avg Speed (kn)</label><input type="number" id="vp-speed" value="14" min="8" max="25"></div>
              <div class="fg"><label>Fuel Price ($/MT)</label><input type="number" id="vp-fprice" value="680" min="200"></div>
            </div>
            <div class="fr3">
              <div class="fg"><label>Cargo Volume (TEU)</label><input type="number" id="vp-cargo" value="18000" min="100"></div>
              <div class="fg"><label>Weather Severity</label>
                <select id="vp-weather"><option value="1">Calm (0%)</option><option value="1.05" selected>Light (5%)</option><option value="1.12">Moderate (12%)</option><option value="1.22">Heavy (22%)</option></select>
              </div>
              <div class="fg"><label>Vessel Type</label>
                <select id="vp-vessel"><option value="400">ULCV (400 MT/d)</option><option value="280" selected>Large CV (280 MT/d)</option><option value="160">Feeder (160 MT/d)</option></select>
              </div>
            </div>
            <div class="fr2">
              <div class="fg"><label>Freight Rate ($/TEU)</label><input type="number" id="vp-rate" value="1800" min="100"></div>
              <div class="fg"><label>Canal Fee ($)</label><input type="number" id="vp-canal" value="280000"></div>
            </div>
            <button class="btn btn-p" style="width:100%" onclick="calcVoyage()">▶ Calculate Voyage</button>
          </div>
        </div>

        <div>
          <div class="g2 mb14">
            <div class="card"><div class="kpi-label mb6">Voyage Duration</div><div class="kpi-value text-blue mono" id="vp-r-duration">32.3 days</div><div class="kpi-sub text3">Origin to destination</div></div>
            <div class="card"><div class="kpi-label mb6">Total Fuel</div><div class="kpi-value text-amber mono" id="vp-r-fuel">9,044 MT</div><div class="kpi-sub text3">Including port ops</div></div>
            <div class="card"><div class="kpi-label mb6">Fuel Cost</div><div class="kpi-value text-red mono" id="vp-r-fcost">$6.15M</div><div class="kpi-sub text3">At current price</div></div>
            <div class="card"><div class="kpi-label mb6">CO₂ Emission</div><div class="kpi-value text-amber mono" id="vp-r-co2">28,440 tCO₂</div><div class="kpi-sub text3">VLSFO factor</div></div>
            <div class="card"><div class="kpi-label mb6">Total Revenue</div><div class="kpi-value text-green mono" id="vp-r-rev">$32.4M</div><div class="kpi-sub text3">Freight revenue</div></div>
            <div class="card"><div class="kpi-label mb6">Gross Profit</div><div class="kpi-value text-green mono" id="vp-r-profit">$18.2M</div><div class="kpi-sub text3" id="vp-r-margin">Margin: 56.2%</div></div>
          </div>
          <div class="card">
            <div class="card-title">💰 Cost Breakdown</div>
            <div class="ch"><canvas id="ch-voyage-cost"></canvas></div>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-port" class="section">
      <div class="shdr mb14">
        <div><h2>⚓ Port Operations</h2><div class="sub">Global port performance · Berth utilization · Queue management</div></div>
      </div>
      <div class="g4 mb14">
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">Active Ports</div><div class="kpi-value text-blue">18</div></div><div class="kpi-icon blue">⚓</div></div><div class="kpi-sub">Global network</div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">Vessels in Queue</div><div class="kpi-value text-amber">23</div></div><div class="kpi-icon amber">⏳</div></div><div class="kpi-sub"><span class="kpi-delta dn">↑ 5</span> vs yesterday</div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">Avg Berth Util</div><div class="kpi-value text-green">72.4%</div></div><div class="kpi-icon green">📊</div></div><div class="kpi-sub">Target: 80%</div></div>
        <div class="kpi red"><div class="kpi-top"><div><div class="kpi-label">Congested Ports</div><div class="kpi-value text-red">4</div></div><div class="kpi-icon red">🚨</div></div><div class="kpi-sub">Immediate action needed</div></div>
      </div>
      <div class="g2 mb14">
        <div class="card">
          <div class="card-title">🏆 Port Performance Ranking</div>
          <table class="tbl">
            <thead><tr><th>#</th><th>Port</th><th>Berth Util</th><th>Avg TAT</th><th>Queue</th><th>Loading Rate</th><th>Status</th></tr></thead>
            <tbody id="port-tbody"></tbody>
          </table>
        </div>
        <div class="card">
          <div class="card-title">📊 Berth Utilization by Port</div>
          <div class="ch-lg"><canvas id="ch-port-berth"></canvas></div>
        </div>
      </div>
      <div class="g2">
        <div class="card">
          <div class="card-title">⏱ Vessel Queue Timeline</div>
          <div id="port-queue-vis"></div>
        </div>
        <div class="card">
          <div class="card-title">📦 Loading / Discharge Rate</div>
          <div class="ch"><canvas id="ch-port-ops"></canvas></div>
        </div>
      </div>
    </div>

    <div id="tab-cargo" class="section">
      <div class="shdr mb14">
        <div><h2>📦 Cargo Management</h2><div class="sub">Multi-commodity tracking · Volume & value analytics</div></div>
      </div>
      <div class="g4 mb14">
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">Active Shipments</div><div class="kpi-value text-blue">384</div></div><div class="kpi-icon blue">📦</div></div><div class="kpi-sub">$2.8B cargo value</div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">Delivered MTD</div><div class="kpi-value text-green">2.4M TEU</div></div><div class="kpi-icon green">✅</div></div><div class="kpi-sub"><span class="kpi-delta up">↑ 8.2%</span></div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">In Transit</div><div class="kpi-value text-amber">1.8M TEU</div></div><div class="kpi-icon amber">🚢</div></div><div class="kpi-sub">Avg ETA: 6.4 days</div></div>
        <div class="kpi red"><div class="kpi-top"><div><div class="kpi-label">Delayed Cargo</div><div class="kpi-value text-red">42K TEU</div></div><div class="kpi-icon red">⚠</div></div><div class="kpi-sub">2.3% of total</div></div>
      </div>
      <div class="g2 mb14">
        <div class="card">
          <div class="card-title">📊 Cargo Type Distribution</div>
          <div class="ch-lg"><canvas id="ch-cargo-type"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">📦 Cargo Volume by Route</div>
          <div class="ch-lg"><canvas id="ch-cargo-route"></canvas></div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">📋 Active Shipment Tracker</div>
        <table class="tbl">
          <thead><tr><th>Shipment ID</th><th>Cargo Type</th><th>Volume</th><th>Value</th><th>Origin</th><th>Destination</th><th>Vessel</th><th>ETA</th><th>Progress</th><th>Status</th></tr></thead>
          <tbody id="cargo-tbody"></tbody>
        </table>
      </div>
    </div>

    <div id="tab-route" class="section">
      <div class="shdr mb14">
        <div><h2>🧭 Route Optimization Engine</h2><div class="sub">AI-powered route intelligence · Weather-aware routing</div></div>
      </div>
      <div class="g-sim">
        <div>
          <div class="card mb14">
            <div class="card-title">⚙️ Route Parameters</div>
            <div class="fr2">
              <div class="fg"><label>Origin</label><select id="ro-origin"><option>Rotterdam</option><option>Singapore</option><option>Shanghai</option><option>Los Angeles</option></select></div>
              <div class="fg"><label>Destination</label><select id="ro-dest"><option>Singapore</option><option>Rotterdam</option><option>Shanghai</option><option>Sydney</option></select></div>
            </div>
            <div class="fr2">
              <div class="fg"><label>Weather Severity</label><select id="ro-weather"><option>Calm</option><option selected>Moderate</option><option>Severe</option></select></div>
              <div class="fg"><label>Priority</label><select id="ro-priority"><option>Cost Optimized</option><option selected>Balanced</option><option>Time Optimized</option></select></div>
            </div>
            <div class="fr2">
              <div class="fg"><label>Avoid Piracy Zone</label><select><option>Yes</option><option>No</option></select></div>
              <div class="fg"><label>Canal Preference</label><select><option>Suez</option><option>Panama</option><option>Lombok</option><option>Cape of Good Hope</option></select></div>
            </div>
            <button class="btn btn-p" style="width:100%;margin-top:4px" onclick="calcRoute()">🧭 Optimize Route</button>
          </div>
          <div class="card">
            <div class="card-title">📊 Route Comparison</div>
            <div id="route-options">
              <div class="route-opt selected">
                <div class="ro-header"><span class="ro-label">🟢 Optimal Route</span><span class="status ok">Recommended</span></div>
                <div class="ro-savings">
                  <div class="ro-save-item"><div class="val" id="ro-dist-saved">-420nm</div><div class="lbl">Distance</div></div>
                  <div class="ro-save-item"><div class="val" id="ro-fuel-saved">-$18K</div><div class="lbl">Fuel Cost</div></div>
                  <div class="ro-save-item"><div class="val" id="ro-time-saved">-14h</div><div class="lbl">Time</div></div>
                  <div class="ro-save-item"><div class="val" id="ro-cost-saved">-$22K</div><div class="lbl">Total Cost</div></div>
                </div>
              </div>
              <div class="route-opt">
                <div class="ro-header"><span class="ro-label">🔵 Alternative Route 1</span><span class="status info">Via Suez</span></div>
                <div class="ro-savings">
                  <div class="ro-save-item"><div class="val" style="color:var(--text2)">+180nm</div><div class="lbl">Distance</div></div>
                  <div class="ro-save-item"><div class="val" style="color:var(--text2)">+$8K</div><div class="lbl">Fuel Cost</div></div>
                  <div class="ro-save-item"><div class="val" style="color:var(--amber)">-6h</div><div class="lbl">Time</div></div>
                  <div class="ro-save-item"><div class="val" style="color:var(--text2)">+$4K</div><div class="lbl">Total Cost</div></div>
                </div>
              </div>
              <div class="route-opt">
                <div class="ro-header"><span class="ro-label">🟡 Alternative Route 2</span><span class="status warn">Cape Route</span></div>
                <div class="ro-savings">
                  <div class="ro-save-item"><div class="val" style="color:var(--red)">+2,200nm</div><div class="lbl">Distance</div></div>
                  <div class="ro-save-item"><div class="val" style="color:var(--red)">+$42K</div><div class="lbl">Fuel Cost</div></div>
                  <div class="ro-save-item"><div class="val" style="color:var(--red)">+5 days</div><div class="lbl">Time</div></div>
                  <div class="ro-save-item"><div class="val" style="color:var(--green)">Canal Fee $0</div><div class="lbl">Canal Fee</div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div class="card mb14">
            <div class="card-title">🗺 Route Visualization</div>
            <div class="map-canvas" style="height:300px;border-radius:8px">
              <div class="map-grid"></div>
              <svg style="position:absolute;inset:0;width:100%;height:100%" viewBox="0 0 600 300" preserveAspectRatio="none">
                <path d="M80 130 Q180 100 280 140 Q380 180 480 160" stroke="var(--green)" stroke-width="2.5" fill="none" stroke-dasharray="8,4"/>
                <path d="M80 130 Q150 160 240 180 Q340 200 480 160" stroke="var(--blue-l)" stroke-width="1.5" fill="none" stroke-dasharray="5,5" opacity=".6"/>
                <path d="M80 130 Q100 200 160 230 Q300 260 400 220 Q460 200 480 160" stroke="var(--amber)" stroke-width="1.5" fill="none" stroke-dasharray="5,5" opacity=".5"/>
                <circle cx="80" cy="130" r="5" fill="var(--cyan)"/>
                <circle cx="480" cy="160" r="5" fill="var(--cyan)"/>
                <text x="65" y="122" fill="var(--cyan)" font-size="9" font-family="monospace">Rotterdam</text>
                <text x="462" y="152" fill="var(--cyan)" font-size="9" font-family="monospace">Singapore</text>
              </svg>
            </div>
          </div>
          <div class="g3">
            <div class="card"><div class="port-gauge"><div class="gauge-val text-green" id="ro-r-dist">10,423nm</div><div class="gauge-lbl">Optimal Distance</div></div></div>
            <div class="card"><div class="port-gauge"><div class="gauge-val text-blue" id="ro-r-time">29.8 days</div><div class="gauge-lbl">Voyage Duration</div></div></div>
            <div class="card"><div class="port-gauge"><div class="gauge-val text-green" id="ro-r-save">$22,400</div><div class="gauge-lbl">Total Savings</div></div></div>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-delay" class="section">
      <div class="shdr mb14">
        <div><h2>⏱ Delay Analytics</h2><div class="sub">Root cause analysis · Delay cost intelligence</div></div>
      </div>
      <div class="g4 mb14">
        <div class="kpi red"><div class="kpi-top"><div><div class="kpi-label">Total Delay Hours</div><div class="kpi-value text-red">1,284h</div></div><div class="kpi-icon red">⏱</div></div><div class="kpi-sub">This month</div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">Delay Cost</div><div class="kpi-value text-amber">$4.2M</div></div><div class="kpi-icon amber">💸</div></div><div class="kpi-sub">Revenue impact</div></div>
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">Affected Voyages</div><div class="kpi-value text-blue">38</div></div><div class="kpi-icon blue">🚢</div></div><div class="kpi-sub">22.4% of total</div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">Avg Delay/Voyage</div><div class="kpi-value text-green">33.8h</div></div><div class="kpi-icon green">📊</div></div><div class="kpi-sub">Down from 38.2h</div></div>
      </div>
      <div class="g3 mb14">
        <div class="card">
          <div class="card-title">🥧 Delay Root Causes</div>
          <div class="ch-lg"><canvas id="ch-delay-pie"></canvas></div>
        </div>
        <div class="card g-span-2" style="grid-column:span 2">
          <div class="card-title">📈 Monthly Delay Trend</div>
          <div class="ch-lg"><canvas id="ch-delay-trend"></canvas></div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">📋 Delay Incident Log</div>
        <table class="tbl">
          <thead><tr><th>Vessel</th><th>Route</th><th>Delay Category</th><th>Hours</th><th>Cost Impact</th><th>Action Taken</th><th>Status</th></tr></thead>
          <tbody id="delay-tbody"></tbody>
        </table>
      </div>
    </div>

    <div id="tab-fuel" class="section">
      <div class="shdr mb14">
        <div><h2>⛽ Fuel Management</h2><div class="sub">Consumption analytics · Efficiency benchmarking · Cost optimization</div></div>
      </div>
      <div class="g5 mb14">
        <div class="kpi red"><div class="kpi-top"><div><div class="kpi-label">Fleet Consumption</div><div class="kpi-value text-red">4,820</div></div><div class="kpi-icon red">⛽</div></div><div class="kpi-sub">MT/day total fleet</div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">Monthly Fuel Cost</div><div class="kpi-value text-amber">$26.4M</div></div><div class="kpi-icon amber">💰</div></div><div class="kpi-sub">@$680/MT VLSFO</div></div>
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">Avg Efficiency</div><div class="kpi-value text-blue">38.2 g/nm</div></div><div class="kpi-icon blue">📊</div></div><div class="kpi-sub">Per ton-mile</div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">Best Vessel</div><div class="kpi-value text-green">28.4 g/nm</div></div><div class="kpi-icon green">🏆</div></div><div class="kpi-sub">MV Atlantic Star</div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">Potential Savings</div><div class="kpi-value text-amber">$1.8M</div></div><div class="kpi-icon amber">💡</div></div><div class="kpi-sub">Monthly opportunity</div></div>
      </div>
      <div class="g3 mb14">
        <div class="card">
          <div class="card-title">📈 Consumption Trend (12 months)</div>
          <div class="ch-lg"><canvas id="ch-fuel-cons"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">💰 Fuel Cost Trend</div>
          <div class="ch-lg"><canvas id="ch-fuel-cost"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">🏆 Vessel Efficiency Ranking</div>
          <div id="fuel-ranking"></div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">⛽ Fuel Type Breakdown</div>
        <div class="g4">
          <div style="text-align:center;padding:12px;background:var(--surf2);border-radius:8px">
            <div class="fw8 fs13 text-blue">VLSFO</div><div style="font-size:24px;font-weight:800;color:var(--blue-xl);margin:4px 0">68%</div><div class="fs10 text3">$680/MT</div>
          </div>
          <div style="text-align:center;padding:12px;background:var(--surf2);border-radius:8px">
            <div class="fw8 fs13 text-green">LNG</div><div style="font-size:24px;font-weight:800;color:var(--green);margin:4px 0">18%</div><div class="fs10 text3">$420/MT equiv</div>
          </div>
          <div style="text-align:center;padding:12px;background:var(--surf2);border-radius:8px">
            <div class="fw8 fs13 text-amber">MGO</div><div style="font-size:24px;font-weight:800;color:var(--amber);margin:4px 0">10%</div><div class="fs10 text3">$780/MT</div>
          </div>
          <div style="text-align:center;padding:12px;background:var(--surf2);border-radius:8px">
            <div class="fw8 fs13 text-purple">HFO</div><div style="font-size:24px;font-weight:800;color:var(--purple);margin:4px 0">4%</div><div class="fs10 text3">$420/MT</div>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-cost" class="section">
      <div class="shdr mb14">
        <div><h2>💰 Cost Intelligence</h2><div class="sub">Operating cost analytics · Revenue & profitability</div></div>
      </div>
      <div class="g5 mb14">
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">Total OpEx</div><div class="kpi-value text-blue">$48.2M</div></div><div class="kpi-icon blue">💰</div></div><div class="kpi-sub"><span class="kpi-delta dn">↑ 2.3%</span> vs budget</div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">Fuel Cost</div><div class="kpi-value text-amber">$26.4M</div></div><div class="kpi-icon amber">⛽</div></div><div class="kpi-sub">54.8% of OpEx</div></div>
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">Port Costs</div><div class="kpi-value text-blue">$8.6M</div></div><div class="kpi-icon blue">⚓</div></div><div class="kpi-sub">17.8% of OpEx</div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">Revenue</div><div class="kpi-value text-green">$84.2M</div></div><div class="kpi-icon green">💵</div></div><div class="kpi-sub"><span class="kpi-delta up">↑ 11.3%</span></div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">Net Margin</div><div class="kpi-value text-green">42.8%</div></div><div class="kpi-icon green">📈</div></div><div class="kpi-sub">$36.0M net profit</div></div>
      </div>
      <div class="g2 mb14">
        <div class="card">
          <div class="card-title">💰 Cost Breakdown</div>
          <div class="ch-lg"><canvas id="ch-cost-break"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">📈 Revenue vs Cost Trend</div>
          <div class="ch-lg"><canvas id="ch-rev-cost"></canvas></div>
        </div>
      </div>
      <div class="g3">
        <div class="card">
          <div class="card-title">💸 Cost per TEU</div>
          <div class="esg-score" style="padding:12px">
            <div class="esg-num text-amber">$284</div>
            <div class="esg-grade text2">per TEU</div>
            <div class="fs10 text3 mt8">Target: $260/TEU · Δ +$24 (+9.2%)</div>
          </div>
        </div>
        <div class="card">
          <div class="card-title">🚢 Cost per Voyage</div>
          <div class="esg-score" style="padding:12px">
            <div class="esg-num text-blue">$342K</div>
            <div class="esg-grade text2">per voyage</div>
            <div class="fs10 text3 mt8">Down 4.2% from last quarter</div>
          </div>
        </div>
        <div class="card">
          <div class="card-title">📦 Cost per Ton-Mile</div>
          <div class="esg-score" style="padding:12px">
            <div class="esg-num text-green">$0.012</div>
            <div class="esg-grade text2">per ton-nm</div>
            <div class="fs10 text3 mt8">Industry avg: $0.014</div>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-esg" class="section">
      <div class="shdr mb14">
        <div><h2>🌱 Sustainability Dashboard</h2><div class="sub">ESG metrics · IMO 2030/2050 compliance tracking</div></div>
      </div>
      <div class="g4 mb14">
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">CO₂ MTD</div><div class="kpi-value text-green">14,820t</div></div><div class="kpi-icon green">🌱</div></div><div class="kpi-sub"><span class="kpi-delta up">↓ 3.2%</span> vs last month</div></div>
        <div class="kpi blue"><div class="kpi-top"><div><div class="kpi-label">CII Rating</div><div class="kpi-value text-blue">B+</div></div><div class="kpi-icon blue">📊</div></div><div class="kpi-sub">Fleet average score</div></div>
        <div class="kpi amber"><div class="kpi-top"><div><div class="kpi-label">EEXI Compliance</div><div class="kpi-value text-amber">94.2%</div></div><div class="kpi-icon amber">✅</div></div><div class="kpi-sub">3 vessels pending</div></div>
        <div class="kpi green"><div class="kpi-top"><div><div class="kpi-label">ESG Score</div><div class="kpi-value text-green">72/100</div></div><div class="kpi-icon green">🌿</div></div><div class="kpi-sub">Industry avg: 65</div></div>
      </div>
      <div class="g2 mb14">
        <div class="card">
          <div class="card-title">📊 ESG Score Breakdown</div>
          <div class="esg-score"><div class="esg-num text-green">72</div><div class="esg-grade text-green">B+ Rating</div></div>
          <div class="sep">CII Performance by Vessel</div>
          <div id="cii-vessels"></div>
        </div>
        <div class="card">
          <div class="card-title">🌍 CO₂ Emission Trend</div>
          <div class="ch-lg"><canvas id="ch-co2-trend"></canvas></div>
        </div>
      </div>
      <div class="g3">
        <div class="card">
          <div class="card-title">🌊 Carbon Intensity (gCO₂/nm)</div>
          <div class="ch"><canvas id="ch-carbon-int"></canvas></div>
        </div>
        <div class="card">
          <div class="card-title">⚡ Alternative Fuel Readiness</div>
          <div id="alt-fuel-list" style="padding:4px 0"></div>
        </div>
        <div class="card">
          <div class="card-title">🎯 IMO 2050 Progress</div>
          <div style="padding:8px 0">
            <div class="mb10"><div class="flex btw mb6"><span class="fs11">2030 Target (-40%)</span><span class="fw7 text-green">18%</span></div><div class="prog"><div class="prog-f" style="width:18%;background:var(--amber)"></div></div></div>
            <div class="mb10"><div class="flex btw mb6"><span class="fs11">2040 Target (-70%)</span><span class="fw7 text2">18%</span></div><div class="prog"><div class="prog-f" style="width:18%;background:var(--blue)"></div></div></div>
            <div><div class="flex btw mb6"><span class="fs11">2050 Target (Net Zero)</span><span class="fw7 text2">18%</span></div><div class="prog"><div class="prog-f" style="width:18%;background:var(--purple)"></div></div></div>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-scenario" class="section">
      <div class="shdr mb14">
        <div><h2>🔮 Scenario Simulation</h2><div class="sub">Side-by-side impact analysis · Strategic planning</div></div>
      </div>
      <div class="g-sim mb14">
        <div class="card">
          <div class="card-title">⚙️ Scenario Parameters</div>
          <div class="fr1 fg"><label>Scenario Type</label>
            <select id="sc-type" onchange="runScenario()">
              <option value="fuel">Fuel Price Shock (+30%)</option>
              <option value="congestion">Port Congestion (+50%)</option>
              <option value="weather">Severe Weather Event</option>
              <option value="vessel">Add 3 Vessels</option>
              <option value="route">Optimize All Routes</option>
            </select>
          </div>
          <div class="fr2">
            <div class="fg"><label>Intensity (%)</label><input type="number" id="sc-intensity" value="30" min="1" max="100" onchange="runScenario()"></div>
            <div class="fg"><label>Duration (months)</label><input type="number" id="sc-duration" value="3" min="1" max="24" onchange="runScenario()"></div>
          </div>
          <div class="div"></div>
          <div class="sep">Before Scenario</div>
          <div class="g2 mb10">
            <div><div class="fs10 text3">Monthly Revenue</div><div class="fw8 fs13 text-green">$84.2M</div></div>
            <div><div class="fs10 text3">Monthly Cost</div><div class="fw8 fs13 text-red">$48.2M</div></div>
            <div><div class="fs10 text3">Net Profit</div><div class="fw8 fs13 text-green">$36.0M</div></div>
            <div><div class="fs10 text3">Fleet Util</div><div class="fw8 fs13 text-blue">87.3%</div></div>
          </div>
        </div>
        <div>
          <div class="card mb14">
            <div class="card-title">📊 Scenario Impact Analysis</div>
            <div class="g2 mb12" id="sc-results">
              <div class="card" style="padding:12px"><div class="fs10 text3 mb6">Revenue Impact</div><div class="fw8 fs13" id="sc-r-rev">$84.2M</div><div class="sc-delta neg mt8" id="sc-d-rev">—</div></div>
              <div class="card" style="padding:12px"><div class="fs10 text3 mb6">Cost Impact</div><div class="fw8 fs13" id="sc-r-cost">$62.6M</div><div class="sc-delta neg mt8" id="sc-d-cost">+$14.4M</div></div>
              <div class="card" style="padding:12px"><div class="fs10 text3 mb6">Profit Impact</div><div class="fw8 fs13" id="sc-r-profit">$21.6M</div><div class="sc-delta neg mt8" id="sc-d-profit">-$14.4M</div></div>
              <div class="card" style="padding:12px"><div class="fs10 text3 mb6">ROI Impact</div><div class="fw8 fs13" id="sc-r-roi">25.6%</div><div class="sc-delta neg mt8" id="sc-d-roi">-17.2pp</div></div>
            </div>
            <div class="ch"><canvas id="ch-scenario"></canvas></div>
          </div>
        </div>
      </div>
    </div>

    <div id="tab-report" class="section">
      <div class="shdr mb14">
        <div><h2>📑 Reports Center</h2><div class="sub">Generate, schedule, and export operational reports</div></div>
      </div>
      <div class="g3 mb14">
        <div class="card" style="cursor:pointer;transition:.2s" onmouseover="this.style.borderColor='var(--blue)'" onmouseout="this.style.borderColor='var(--border)'">
          <div class="card-title">📊 Fleet Performance Report</div>
          <div class="fs12 text2 mb12">Comprehensive vessel utilization, speed performance, health scores, and route efficiency metrics.</div>
          <div class="flex gap8 flex-wrap mb10">
            <span class="status info">Monthly</span><span class="status ok">Auto-scheduled</span>
          </div>
          <div class="flex gap8">
            <button class="btn btn-p btn-sm">📄 PDF</button>
            <button class="btn btn-s btn-sm">📊 Excel</button>
            <button class="btn btn-s btn-sm">📋 CSV</button>
          </div>
        </div>
        <div class="card" style="cursor:pointer;transition:.2s" onmouseover="this.style.borderColor='var(--green)'" onmouseout="this.style.borderColor='var(--border)'">
          <div class="card-title">💰 Cost Intelligence Report</div>
          <div class="fs12 text2 mb12">OpEx breakdown, fuel cost analysis, port fees, canal charges, and profitability metrics.</div>
          <div class="flex gap8 flex-wrap mb10">
            <span class="status info">Weekly</span><span class="status warn">On Demand</span>
          </div>
          <div class="flex gap8">
            <button class="btn btn-p btn-sm">📄 PDF</button>
            <button class="btn btn-s btn-sm">📊 Excel</button>
            <button class="btn btn-s btn-sm">📋 CSV</button>
          </div>
        </div>
        <div class="card" style="cursor:pointer;transition:.2s" onmouseover="this.style.borderColor='var(--green)'" onmouseout="this.style.borderColor='var(--border)'">
          <div class="card-title">🌱 Sustainability Report</div>
          <div class="fs12 text2 mb12">CO₂ emissions, CII ratings, EEXI compliance, fuel efficiency, and IMO 2050 progress tracking.</div>
          <div class="flex gap8 flex-wrap mb10">
            <span class="status ok">Quarterly</span><span class="status info">IMO Compliant</span>
          </div>
          <div class="flex gap8">
            <button class="btn btn-p btn-sm">📄 PDF</button>
            <button class="btn btn-s btn-sm">📊 Excel</button>
            <button class="btn btn-s btn-sm">📋 CSV</button>
          </div>
        </div>
        <div class="card">
          <div class="card-title">🗺️ Voyage Report</div>
          <div class="fs12 text2 mb12">Per-voyage analysis: route taken, fuel burn, delays, cargo delivery, and profitability.</div>
          <div class="flex gap8 flex-wrap mb10"><span class="status info">Per Voyage</span></div>
          <div class="flex gap8">
            <button class="btn btn-p btn-sm">📄 PDF</button>
            <button class="btn btn-s btn-sm">📊 Excel</button>
          </div>
        </div>
        <div class="card">
          <div class="card-title">⛽ Fuel Report</div>
          <div class="fs12 text2 mb12">Bunker consumption, fuel grade breakdown, bunkering events, and efficiency benchmarks.</div>
          <div class="flex gap8 flex-wrap mb10"><span class="status warn">Weekly</span></div>
          <div class="flex gap8">
            <button class="btn btn-p btn-sm">📄 PDF</button>
            <button class="btn btn-s btn-sm">📊 Excel</button>
          </div>
        </div>
        <div class="card">
          <div class="card-title">⏱ Delay Analytics Report</div>
          <div class="fs12 text2 mb12">Delay root cause analysis, trend data, cost impact, and recommended actions.</div>
          <div class="flex gap8 flex-wrap mb10"><span class="status ok">Monthly</span></div>
          <div class="flex gap8">
            <button class="btn btn-p btn-sm">📄 PDF</button>
            <button class="btn btn-s btn-sm">📊 Excel</button>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">📋 Recent Reports</div>
        <table class="tbl">
          <thead><tr><th>Report Name</th><th>Type</th><th>Generated</th><th>Period</th><th>Size</th><th>Actions</th></tr></thead>
          <tbody>
            <tr><td class="fw7">Fleet Performance Report - Nov 2025</td><td><span class="status ok">Fleet</span></td><td>2025-11-30</td><td>Nov 2025</td><td>2.4 MB</td><td><button class="btn btn-s btn-sm">⬇ Download</button></td></tr>
            <tr><td class="fw7">Cost Intelligence Report - W48</td><td><span class="status info">Cost</span></td><td>2025-11-28</td><td>Week 48</td><td>1.8 MB</td><td><button class="btn btn-s btn-sm">⬇ Download</button></td></tr>
            <tr><td class="fw7">Sustainability Q3 2025</td><td><span class="status ok">ESG</span></td><td>2025-10-01</td><td>Q3 2025</td><td>4.2 MB</td><td><button class="btn btn-s btn-sm">⬇ Download</button></td></tr>
            <tr><td class="fw7">Fuel Management - Nov 2025</td><td><span class="status warn">Fuel</span></td><td>2025-11-25</td><td>Nov 2025</td><td>1.1 MB</td><td><button class="btn btn-s btn-sm">⬇ Download</button></td></tr>
          </tbody>
        </table>
      </div>
    </div>

  </div></div><div class="ai-chat">
  <div class="ai-panel" id="ai-panel">
    <div class="ai-head">
      <span style="font-size:18px">🤖</span>
      <div><div class="ai-title">ShipFlow AI Copilot</div><div class="ai-sub">Maritime Intelligence Assistant</div></div>
    </div>
    <div class="ai-msgs" id="ai-msgs">
      <div class="ai-msg bot">👋 Hello! I'm your maritime AI assistant. Ask me about fleet performance, routes, costs, or sustainability.</div>
      <div class="ai-msg bot">💡 <strong>Try asking:</strong><br>"What's the most efficient route to Shanghai?"<br>"Which vessel has the highest fuel consumption?"<br>"How can I reduce CO₂ emissions?"</div>
    </div>
    <div class="ai-input-row">
      <input type="text" id="ai-input" placeholder="Ask ShipFlow AI..." onkeydown="if(event.key==='Enter')sendAI()">
      <button class="ai-send" onclick="sendAI()">➤</button>
    </div>
  </div>
  <button class="ai-toggle" onclick="document.getElementById('ai-panel').classList.toggle('open')">🤖</button>
</div>

<script>
// ════════════════════════════════════════════════════════
// DATA
// ════════════════════════════════════════════════════════
const MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const VESSELS=[
  {name:'MV Atlantic Star',imo:'9234567',type:'ULCV',cap:'24,000 TEU',pos:'N Atlantic',spd:15.2,fuel:380,util:94,eta:'Dec 12',health:92,status:'sailing'},
  {name:'MV Pacific Glory',imo:'9345678',type:'ULCV',cap:'23,500 TEU',pos:'Indian Ocean',spd:14.8,fuel:365,util:88,eta:'Dec 18',health:87,status:'sailing'},
  {name:'MV Singapore Express',imo:'9456789',type:'Large CV',cap:'14,000 TEU',pos:'Singapore',spd:0,fuel:180,util:76,eta:'Dec 8',health:91,status:'loading'},
  {name:'MV Shanghai King',imo:'9567890',type:'Large CV',cap:'15,200 TEU',pos:'Shanghai',spd:0,fuel:140,util:82,eta:'Dec 10',health:85,status:'waiting'},
  {name:'MV Arabian Sea',imo:'9678901',type:'Large CV',cap:'13,800 TEU',pos:'Red Sea',spd:11.2,fuel:290,util:71,eta:'Dec 22',health:78,status:'delayed'},
  {name:'MV Eastern Wind',imo:'9789012',type:'Large CV',cap:'14,200 TEU',pos:'S China Sea',spd:14.4,fuel:410,util:89,eta:'Dec 15',health:82,status:'sailing'},
  {name:'MV Rotterdam Bay',imo:'9890123',type:'Feeder',cap:'4,800 TEU',pos:'Rotterdam',spd:0,fuel:80,util:0,eta:'—',health:63,status:'maintenance'},
  {name:'MV Indian Ocean',imo:'9901234',type:'Large CV',cap:'13,500 TEU',pos:'Arabian Sea',spd:15.6,fuel:342,util:92,eta:'Dec 19',health:94,status:'sailing'},
  {name:'MV South Atlantic',imo:'9012345',type:'Bulker',cap:'180,000 DWT',pos:'S Atlantic',spd:13.2,fuel:52,util:97,eta:'Dec 28',health:88,status:'sailing'},
  {name:'MV Sydney Cove',imo:'9123456',type:'Feeder',cap:'3,200 TEU',pos:'Sydney',spd:0,fuel:95,util:68,eta:'Dec 9',health:89,status:'loading'},
];
const PORTS=[
  {name:'Shanghai',country:'China',berth:88,tat:18.2,queue:8,loading:3200,status:'crit'},
  {name:'Singapore',country:'Singapore',berth:82,tat:20.4,queue:12,loading:2800,status:'warn'},
  {name:'Rotterdam',country:'Netherlands',berth:74,tat:22.8,queue:4,loading:2400,status:'ok'},
  {name:'Dubai Jebel Ali',country:'UAE',berth:71,tat:24.2,queue:6,loading:2200,status:'warn'},
  {name:'Los Angeles',country:'USA',berth:68,tat:26.4,queue:9,loading:1800,status:'warn'},
  {name:'Hamburg',country:'Germany',berth:65,tat:20.8,queue:3,loading:1600,status:'ok'},
  {name:'Busan',country:'S. Korea',berth:79,tat:16.4,queue:5,loading:2600,status:'ok'},
  {name:'Hong Kong',country:'China',berth:72,tat:19.8,queue:7,loading:2100,status:'ok'},
];
const CARGOES=[
  {id:'SF-2025-8841',type:'Container',vol:'18,420 TEU',val:'$284M',origin:'Shanghai',dest:'Rotterdam',vessel:'MV Atlantic Star',eta:'Dec 12',prog:68,status:'sailing'},
  {id:'SF-2025-8842',type:'Bulk Coal',vol:'82,400 MT',val:'$12.4M',origin:'Newcastle',dest:'Qingdao',vessel:'MV South Atlantic',eta:'Dec 28',prog:42,status:'sailing'},
  {id:'SF-2025-8843',type:'Container',vol:'14,200 TEU',val:'$186M',origin:'Rotterdam',dest:'Singapore',vessel:'MV Pacific Glory',eta:'Dec 18',prog:55,status:'sailing'},
  {id:'SF-2025-8844',type:'LNG',vol:'48,000 m³',val:'$28.8M',origin:'Qatar',dest:'Tokyo',vessel:'MV Indian Ocean',eta:'Dec 19',prog:71,status:'sailing'},
  {id:'SF-2025-8845',type:'Container',vol:'13,800 TEU',val:'$142M',origin:'Singapore',dest:'Los Angeles',vessel:'MV Arabian Sea',eta:'Dec 22',prog:34,status:'delayed'},
  {id:'SF-2025-8846',type:'Iron Ore',vol:'120,000 MT',val:'$14.4M',origin:'Brazil',dest:'China',vessel:'MV South Atlantic',eta:'Jan 8',prog:18,status:'sailing'},
];
const DELAYS=[
  {vessel:'MV Arabian Sea',route:'SIN→LAX',cat:'Weather',hrs:42,cost:'$126,000',action:'Speed adjustment',status:'crit'},
  {vessel:'MV Shanghai King',route:'RTM→SHA',cat:'Port Congestion',hrs:28,cost:'$84,000',action:'Berth reassigned',status:'warn'},
  {vessel:'MV Eastern Wind',route:'SHA→SIN',cat:'Mechanical',hrs:16,cost:'$48,000',action:'Engine repair',status:'warn'},
  {vessel:'MV Pacific Glory',route:'RTM→SIN',cat:'Weather',hrs:22,cost:'$66,000',action:'Alternate route',status:'ok'},
  {vessel:'MV Rotterdam Bay',route:'HAM→RTM',cat:'Maintenance',hrs:72,cost:'$216,000',action:'Drydock scheduled',status:'crit'},
];

const fmtK=v=>v>=1e6?'$'+(v/1e6).toFixed(1)+'M':v>=1e3?'$'+(v/1e3).toFixed(0)+'K':'$'+v;

// ════════════════════════════════════════════════════════
// INIT CHARTS
// ════════════════════════════════════════════════════════
const CHART_DEFAULTS={
  plugins:{legend:{labels:{color:'#94a3b8',font:{size:10,family:'Sora'}}}},
  scales:{x:{ticks:{color:'#4b5e7a',font:{size:10}},grid:{color:'rgba(30,47,74,.4)'}},y:{ticks:{color:'#4b5e7a',font:{size:10}},grid:{color:'rgba(30,47,74,.4)'}}}
};
function mkChart(id,type,labels,datasets,opts={}){
  const ctx=document.getElementById(id);if(!ctx)return;
  new Chart(ctx,{type,data:{labels,datasets},options:{responsive:true,maintainAspectRatio:false,...CHART_DEFAULTS,...opts}});
}
function rgba(c,a){return c.replace(')',\`,$\{a})\`).replace('rgb(','rgba(')}

function initDashboardCharts(){
  // Fleet status donut
  mkChart('ch-fleet-status','doughnut',['Sailing','Loading','Waiting','Delayed','Maint.'],[{data:[28,6,4,3,1],backgroundColor:['#10b981','#3b82f6','#f59e0b','#ef4444','#8b5cf6'],borderWidth:0,hoverOffset:4}],{plugins:{legend:{position:'bottom',labels:{color:'#94a3b8',font:{size:9},padding:8}}}});
  // Revenue trend
  mkChart('ch-revenue','bar',MONTHS,[
    {label:'Revenue $M',data:[68,72,74,69,78,82,76,84,88,80,84,90],backgroundColor:'rgba(16,185,129,.5)',borderColor:'#10b981',borderWidth:1},
    {label:'Cost $M',data:[42,44,43,40,46,48,44,48,50,46,48,52],backgroundColor:'rgba(239,68,68,.3)',borderColor:'#ef4444',borderWidth:1}
  ]);
  // Fuel trend
  mkChart('ch-fuel-trend','line',MONTHS,[
    {label:'Fuel Cost $M',data:[24,25,23,22,26,28,25,26,28,24,26,27],borderColor:'#f59e0b',backgroundColor:'rgba(245,158,11,.1)',tension:.4,fill:true,pointRadius:3}
  ]);
  // Voyage dist
  mkChart('ch-voyage-dist','bar',['<14d','14-21d','21-28d','28-35d','>35d'],[{label:'Voyages',data:[8,24,38,22,8],backgroundColor:['#3b82f6','#10b981','#f59e0b','#8b5cf6','#ef4444'],borderRadius:4}]);
}

function initFleetCharts(){
  const tbody=document.getElementById('fleet-tbody');
  if(tbody){
    tbody.innerHTML=VESSELS.map(v=>{
      const hc=v.health>=85?'green':v.health>=70?'amber':'red';
      return \`<tr>
        <td class="fw7">\${v.name}</td>
        <td class="mono text3">\${v.imo}</td>
        <td>\${v.type}</td>
        <td>\${v.cap}</td>
        <td class="text2">\${v.pos}</td>
        <td class="mono">\${v.spd?v.spd+' kn':'—'}</td>
        <td class="mono">\${v.fuel} MT/d</td>
        <td><div class="flex gap6"><span class="mono">\${v.util}%</span><div class="prog" style="width:50px;margin:0"><div class="prog-f" style="width:\${v.util}%;background:var(--\${hc})"></div></div></div></td>
        <td class="text2">\${v.eta}</td>
        <td><span class="fw7 text-\${hc} mono">\${v.health}</span></td>
        <td><span class="status \${v.status}">\${v.status}</span></td>
      </tr>\`;
    }).join('');
  }
  mkChart('ch-fleet-util','bar',['ULCV','Large CV','Feeder','Bulker','Tanker'],[
    {label:'Utilization %',data:[91,87,74,97,82],backgroundColor:'rgba(37,99,235,.6)',borderColor:'var(--blue)',borderWidth:1,borderRadius:4},
    {label:'Target %',data:[90,90,80,95,85],backgroundColor:'rgba(16,185,129,.2)',borderColor:'var(--green)',borderWidth:1,borderRadius:4}
  ]);
  const tv=document.getElementById('top-vessels');
  if(tv){
    tv.innerHTML=VESSELS.slice(0,6).sort((a,b)=>b.health-a.health).map(v=>\`
      <div class="flex btw mb8" style="padding:6px 0;border-bottom:1px solid var(--border)">
        <span class="fs11 fw7">\${v.name}</span>
        <div class="flex gap8">
          <span class="fs11 mono text-blue">\${v.util}% util</span>
          <span class="fs11 mono text-green">\${v.health}/100</span>
        </div>
      </div>\`).join('');
  }
}

function initPortCharts(){
  const tbody=document.getElementById('port-tbody');
  if(tbody){
    tbody.innerHTML=PORTS.map((p,i)=>\`<tr>
      <td class="fw7 text-blue">#\${i+1}</td>
      <td class="fw7">\${p.name}</td>
      <td class="mono">\${p.country}</td>
      <td><div class="flex gap6"><span class="mono">\${p.berth}%</span><div class="prog" style="width:50px;margin:0"><div class="prog-f" style="width:\${p.berth}%;background:var(--blue)"></div></div></div></td>
      <td class="mono">\${p.tat}h</td>
      <td class="mono text-amber">\${p.queue}</td>
      <td class="mono">\${p.loading.toLocaleString()} mv/h</td>
      <td><span class="status \${p.status==='crit'?'crit':p.status==='warn'?'warn':'ok'}">\${p.status==='ok'?'Normal':p.status==='warn'?'Busy':'Congested'}</span></td>
    </tr>\`).join('');
  }
  mkChart('ch-port-berth','bar',PORTS.map(p=>p.name),[
    {label:'Berth Utilization %',data:PORTS.map(p=>p.berth),backgroundColor:PORTS.map(p=>p.berth>=80?'rgba(239,68,68,.6)':p.berth>=70?'rgba(245,158,11,.6)':'rgba(16,185,129,.6)'),borderRadius:4}
  ]);
  mkChart('ch-port-ops','bar',PORTS.slice(0,6).map(p=>p.name),[
    {label:'Loading Rate',data:[3200,2800,2400,2200,1800,1600],backgroundColor:'rgba(37,99,235,.5)',borderRadius:3},
    {label:'Discharge Rate',data:[2800,2400,2200,1900,1600,1400],backgroundColor:'rgba(16,185,129,.4)',borderRadius:3}
  ]);
  const qv=document.getElementById('port-queue-vis');
  if(qv){
    qv.innerHTML=PORTS.slice(0,6).map(p=>\`
      <div class="flex btw mb8" style="padding:6px 0;border-bottom:1px solid var(--border)">
        <span class="fs11 fw7">\${p.name}</span>
        <div class="flex gap8">
          <span class="fs10 text3">\${p.queue} vessels waiting</span>
          <span class="fs11 mono text-amber">\${(p.queue*2.4).toFixed(0)}h est delay</span>
        </div>
      </div>\`).join('');
  }
}

function initCargoCharts(){
  const tbody=document.getElementById('cargo-tbody');
  if(tbody){
    tbody.innerHTML=CARGOES.map(c=>\`<tr>
      <td class="mono fw7 text-blue">\${c.id}</td>
      <td>\${c.type}</td>
      <td>\${c.vol}</td>
      <td class="fw7 text-green">\${c.val}</td>
      <td class="text2">\${c.origin}</td>
      <td class="text2">\${c.dest}</td>
      <td>\${c.vessel}</td>
      <td class="mono">\${c.eta}</td>
      <td><div class="flex gap6 align-center"><div class="prog" style="width:60px"><div class="prog-f" style="width:\${c.prog}%;background:var(--blue)"></div></div><span class="fs10 mono">\${c.prog}%</span></div></td>
      <td><span class="status \${c.status}">\${c.status}</span></td>
    </tr>\`).join('');
  }
  mkChart('ch-cargo-type','doughnut',['Container','Bulk','LNG','Oil','Iron Ore','Coal'],[
    {data:[48,18,12,10,8,4],backgroundColor:['#2563eb','#10b981','#06b6d4','#8b5cf6','#f59e0b','#ef4444'],borderWidth:0,hoverOffset:4}
  ],{plugins:{legend:{position:'right',labels:{color:'#94a3b8',font:{size:10}}}}});
  mkChart('ch-cargo-route','bar',['Asia-Europe','Trans-Pacific','Asia-Oceania','Intra-Asia','Europe-Americas'],[
    {label:'Volume (k TEU)',data:[680,420,180,520,240],backgroundColor:'rgba(37,99,235,.6)',borderRadius:4}
  ]);
}

function initDelayCharts(){
  const tbody=document.getElementById('delay-tbody');
  if(tbody){
    tbody.innerHTML=DELAYS.map(d=>\`<tr>
      <td class="fw7">\${d.vessel}</td>
      <td class="text2">\${d.route}</td>
      <td>\${d.cat}</td>
      <td class="mono fw7 text-red">\${d.hrs}h</td>
      <td class="mono text-amber">\${d.cost}</td>
      <td class="text2">\${d.action}</td>
      <td><span class="status \${d.status}">\${d.status==='ok'?'Resolved':d.status==='warn'?'In Progress':'Critical'}</span></td>
    </tr>\`).join('');
  }
  mkChart('ch-delay-pie','doughnut',['Weather','Port Congestion','Mechanical','Customs','Crew Change'],[
    {data:[38,28,18,10,6],backgroundColor:['#3b82f6','#f59e0b','#ef4444','#8b5cf6','#10b981'],borderWidth:0}
  ],{plugins:{legend:{position:'bottom',labels:{color:'#94a3b8',font:{size:9}}}}});
  mkChart('ch-delay-trend','line',MONTHS,[
    {label:'Delay Hours',data:[1420,1380,1250,1180,1320,1440,1260,1340,1280,1200,1284,1180],borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,.1)',tension:.4,fill:true},
    {label:'Delay Cost $K',data:[4260,4140,3750,3540,3960,4320,3780,4020,3840,3600,4200,3540],borderColor:'#f59e0b',backgroundColor:'rgba(245,158,11,.05)',tension:.4,yAxisID:'y1'}
  ],{scales:{...CHART_DEFAULTS.scales,y1:{type:'linear',position:'right',ticks:{color:'#4b5e7a',font:{size:10}},grid:{drawOnChartArea:false}}}});
}

function initFuelCharts(){
  mkChart('ch-fuel-cons','line',MONTHS,[
    {label:'Consumption MT/day',data:[4620,4800,4580,4420,4940,5120,4760,4820,4980,4640,4820,4900],borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,.1)',tension:.4,fill:true}
  ]);
  mkChart('ch-fuel-cost','line',MONTHS,[
    {label:'Fuel Cost $M',data:[23.5,24.4,23.3,22.5,25.1,26.0,24.2,24.5,25.3,23.6,24.4,24.9],borderColor:'#f59e0b',backgroundColor:'rgba(245,158,11,.1)',tension:.4,fill:true}
  ]);
  const fr=document.getElementById('fuel-ranking');
  if(fr){
    const vessels=[...VESSELS].filter(v=>v.fuel>0).sort((a,b)=>a.fuel-b.fuel);
    fr.innerHTML=vessels.map(v=>{
      const eff=(v.fuel/v.spd||v.fuel/14).toFixed(1);
      const clr=v.fuel<200?'green':v.fuel<320?'amber':'red';
      return \`<div class="flex btw mb8" style="padding:5px 0;border-bottom:1px solid var(--border)">
        <span class="fs11">\${v.name.replace('MV ','')}</span>
        <span class="mono fw7 text-\${clr}">\${v.fuel} MT/d</span>
      </div>\`;
    }).join('');
  }
}

function initCostCharts(){
  mkChart('ch-cost-break','doughnut',['Fuel','Port Fees','Crew','Canal Fees','Maintenance','Insurance','Other'],[
    {data:[54.8,17.8,10.4,7.2,4.8,3.2,1.8],backgroundColor:['#f59e0b','#3b82f6','#10b981','#8b5cf6','#ef4444','#06b6d4','#6b7280'],borderWidth:0}
  ],{plugins:{legend:{position:'right',labels:{color:'#94a3b8',font:{size:9}}}}});
  mkChart('ch-rev-cost','line',MONTHS,[
    {label:'Revenue $M',data:[68,72,74,69,78,82,76,84,88,80,84,90],borderColor:'#10b981',tension:.4,fill:false},
    {label:'OpEx $M',data:[42,44,43,40,46,48,44,48,50,46,48,52],borderColor:'#ef4444',tension:.4,fill:false},
    {label:'Net Profit $M',data:[26,28,31,29,32,34,32,36,38,34,36,38],borderColor:'#2563eb',tension:.4,fill:false}
  ]);
}

function initESGCharts(){
  mkChart('ch-co2-trend','line',MONTHS,[
    {label:'CO₂ tCO₂/month',data:[16200,15800,15400,14900,15600,16100,15200,15400,15100,14600,14820,14400],borderColor:'#10b981',backgroundColor:'rgba(16,185,129,.1)',tension:.4,fill:true}
  ]);
  mkChart('ch-carbon-int','bar',VESSELS.slice(0,6).map(v=>v.name.replace('MV ','')),[
    {label:'gCO₂/nm',data:[42,45,38,52,36,58],backgroundColor:VESSELS.slice(0,6).map((_,i)=>[42,45,38,52,36,58][i]>45?'rgba(239,68,68,.6)':'rgba(16,185,129,.6)'),borderRadius:4}
  ]);
  const ciiEl=document.getElementById('cii-vessels');
  if(ciiEl){
    const ratings=['A','A','B','B','C','B','D','A'];
    const rColors={'A':'var(--green)','B':'var(--blue-xl)','C':'var(--amber)','D':'var(--red)'};
    ciiEl.innerHTML=VESSELS.slice(0,6).map((v,i)=>\`
      <div class="flex btw mb8" style="padding:5px 0;border-bottom:1px solid var(--border)">
        <span class="fs11">\${v.name.replace('MV ','')}</span>
        <span class="fw8 fs13" style="color:\${rColors[ratings[i]]}">\${ratings[i]}</span>
      </div>\`).join('');
  }
  const afEl=document.getElementById('alt-fuel-list');
  if(afEl){
    const fuels=[{name:'LNG Ready',pct:42,clr:'var(--green)'},{name:'Methanol Ready',pct:18,clr:'var(--blue-xl)'},{name:'Ammonia Capable',pct:8,clr:'var(--cyan)'},{name:'Wind Assist',pct:12,clr:'var(--amber)'}];
    afEl.innerHTML=fuels.map(f=>\`
      <div class="mb10">
        <div class="flex btw mb6"><span class="fs11">\${f.name}</span><span class="mono fw7" style="color:\${f.clr}">\${f.pct}%</span></div>
        <div class="prog"><div class="prog-f" style="width:\${f.pct}%;background:\${f.clr}"></div></div>
      </div>\`).join('');
  }
}

function initScenarioChart(){
  mkChart('ch-scenario','bar',['Revenue','OpEx','Fuel Cost','Net Profit'],[
    {label:'Before',data:[84.2,48.2,26.4,36.0],backgroundColor:'rgba(37,99,235,.5)',borderRadius:4},
    {label:'After Scenario',data:[84.2,62.6,34.3,21.6],backgroundColor:'rgba(239,68,68,.5)',borderRadius:4}
  ]);
}

// ════════════════════════════════════════════════════════
// VOYAGE CALC
// ════════════════════════════════════════════════════════
function calcVoyage(){
  const dist=+document.getElementById('vp-dist').value;
  const spd=+document.getElementById('vp-speed').value;
  const fprice=+document.getElementById('vp-fprice').value;
  const cargo=+document.getElementById('vp-cargo').value;
  const wxFactor=+document.getElementById('vp-weather').value;
  const baseFuel=+document.getElementById('vp-vessel').value;
  const rate=+document.getElementById('vp-rate').value;
  const canal=+document.getElementById('vp-canal').value;

  const dur=(dist/(spd*24))*wxFactor;
  const fuel=baseFuel*dur;
  const fcost=fuel*fprice;
  const co2=fuel*3.114;
  const rev=cargo*rate;
  const crewCost=dur*2800*24;
  const portCost=480000;
  const totalCost=fcost+crewCost+portCost+canal;
  const profit=rev-totalCost;
  const margin=(profit/rev*100);

  document.getElementById('vp-r-duration').textContent=dur.toFixed(1)+' days';
  document.getElementById('vp-r-fuel').textContent=Math.round(fuel).toLocaleString()+' MT';
  document.getElementById('vp-r-fcost').textContent='$'+(fcost/1e6).toFixed(2)+'M';
  document.getElementById('vp-r-co2').textContent=Math.round(co2).toLocaleString()+' tCO₂';
  document.getElementById('vp-r-rev').textContent='$'+(rev/1e6).toFixed(1)+'M';
  document.getElementById('vp-r-profit').textContent=profit>0?'$'+(profit/1e6).toFixed(1)+'M':'−$'+(Math.abs(profit)/1e6).toFixed(1)+'M';
  document.getElementById('vp-r-margin').textContent='Margin: '+margin.toFixed(1)+'%';

  // Rebuild cost pie
  const ctx=document.getElementById('ch-voyage-cost');
  if(ctx){
    const existing=Chart.getChart(ctx);if(existing)existing.destroy();
    new Chart(ctx,{type:'doughnut',data:{labels:['Fuel','Crew','Port','Canal'],datasets:[{data:[fcost,crewCost,portCost,canal].map(v=>+(v/1000).toFixed(0)),backgroundColor:['#f59e0b','#3b82f6','#10b981','#8b5cf6'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{color:'#94a3b8',font:{size:9}}}}}});
  }
}

// ════════════════════════════════════════════════════════
// ROUTE CALC
// ════════════════════════════════════════════════════════
function calcRoute(){
  const savings=['-420nm','-$18K','-14h','-$22K'];
  document.getElementById('ro-dist-saved').textContent=savings[0];
  document.getElementById('ro-fuel-saved').textContent=savings[1];
  document.getElementById('ro-time-saved').textContent=savings[2];
  document.getElementById('ro-cost-saved').textContent=savings[3];
}

// ════════════════════════════════════════════════════════
// SCENARIO CALC
// ════════════════════════════════════════════════════════
function runScenario(){
  const type=document.getElementById('sc-type').value;
  const intensity=+document.getElementById('sc-intensity').value/100;

  let revAfter=84.2,costAfter=48.2,fuelAfter=26.4;
  if(type==='fuel'){fuelAfter=26.4*(1+intensity);costAfter=48.2+(fuelAfter-26.4);}
  else if(type==='congestion'){costAfter=48.2*(1+intensity*0.3);revAfter=84.2*(1-intensity*0.1);}
  else if(type==='weather'){costAfter=48.2*(1+intensity*0.2);revAfter=84.2*(1-intensity*0.08);}
  else if(type==='vessel'){revAfter=84.2*(1+intensity*0.05);costAfter=48.2*(1+intensity*0.04);}
  else if(type==='route'){costAfter=48.2*(1-intensity*0.15);revAfter=84.2*(1+intensity*0.02);}

  const profitAfter=revAfter-costAfter;
  const roiAfter=(profitAfter/costAfter*100);

  document.getElementById('sc-r-rev').textContent='$'+revAfter.toFixed(1)+'M';
  document.getElementById('sc-r-cost').textContent='$'+costAfter.toFixed(1)+'M';
  document.getElementById('sc-r-profit').textContent='$'+profitAfter.toFixed(1)+'M';
  document.getElementById('sc-r-roi').textContent=roiAfter.toFixed(1)+'%';

  const drev=(revAfter-84.2).toFixed(1);
  const dcost=(costAfter-48.2).toFixed(1);
  const dprof=(profitAfter-36.0).toFixed(1);
  document.getElementById('sc-d-rev').textContent=(drev>0?'+':'')+drev+'M';
  document.getElementById('sc-d-cost').textContent=(dcost>0?'+':'')+dcost+'M';
  document.getElementById('sc-d-profit').textContent=(dprof>0?'+':'')+dprof+'M';
  document.getElementById('sc-d-rev').className='sc-delta '+(drev>=0?'pos':'neg');
  document.getElementById('sc-d-cost').className='sc-delta '+(dcost<=0?'pos':'neg');
  document.getElementById('sc-d-profit').className='sc-delta '+(dprof>=0?'pos':'neg');
}

// ════════════════════════════════════════════════════════
// AI CHAT
// ════════════════════════════════════════════════════════
const AI_RESPONSES={
  'route':['The optimal route from Rotterdam to Singapore via Suez Canal saves approximately $22,400 per voyage compared to Cape of Good Hope routing.','I recommend avoiding the South China Sea route in the next 48h due to Typhoon advisory. Lombok Strait alternative is available.'],
  'fuel':['MV Eastern Wind is consuming 12% above baseline (410 MT/day vs target 365 MT/day). Recommend engine diagnostic and speed reduction by 1 knot.','Fleet average fuel efficiency is 38.2g/tonne-nm. Best performer: MV Atlantic Star at 28.4g/tonne-nm.'],
  'port':['Singapore Port is currently congested with 12 vessels in queue. Expected delay: 8-12 hours. Consider rerouting 2 vessels to Tanjung Pelepas.','Rotterdam Port has 4 vessels in queue with 22.8h average turnaround. Berth utilization at 74% — within normal range.'],
  'emission':['Fleet CO₂ emissions are down 3.2% month-over-month. Current CII fleet average: B+. Target: B by Q4 2026.','Slow steaming by 1 knot across all ULCV vessels would reduce fuel consumption by 8% and CO₂ by ~1,180 tCO₂/month.'],
  'vessel':['MV Rotterdam Bay is in maintenance (health score: 63). Drydock scheduled for 10 days. Estimated return: December 18.','MV Atlantic Star has the highest health score (92) and best fuel efficiency in the fleet.'],
  'default':['Based on current fleet data, I recommend reviewing the 4 congested ports and rerouting 6 vessels for optimal performance.','Fleet utilization is at 87.3%, above the industry average of 82%. Revenue per vessel is tracking at $2.0M/month.']
};

function sendAI(){
  const inp=document.getElementById('ai-input');
  const msgs=document.getElementById('ai-msgs');
  const text=inp.value.trim();
  if(!text)return;

  // User message
  msgs.innerHTML+=\`<div class="ai-msg user">\${text}</div>\`;
  inp.value='';
  msgs.scrollTop=msgs.scrollHeight;

  // Bot response
  setTimeout(()=>{
    const lower=text.toLowerCase();
    let responses=AI_RESPONSES.default;
    if(lower.includes('route')||lower.includes('optimal'))responses=AI_RESPONSES.route;
    else if(lower.includes('fuel')||lower.includes('consumption'))responses=AI_RESPONSES.fuel;
    else if(lower.includes('port')||lower.includes('singapore')||lower.includes('congestion'))responses=AI_RESPONSES.port;
    else if(lower.includes('emission')||lower.includes('co2')||lower.includes('carbon'))responses=AI_RESPONSES.emission;
    else if(lower.includes('vessel')||lower.includes('ship'))responses=AI_RESPONSES.vessel;

    const resp=responses[Math.floor(Math.random()*responses.length)];
    msgs.innerHTML+=\`<div class="ai-msg bot">🤖 \${resp}</div>\`;
    msgs.scrollTop=msgs.scrollHeight;
  },600);
}

// ════════════════════════════════════════════════════════
// NAVIGATION
// ════════════════════════════════════════════════════════
const TAB_META={
  'dashboard':['📊','Executive Dashboard','/ Overview'],
  'fleet':['🚢','Fleet Management','/ Vessels'],
  'voyage':['🗺️','Voyage Planning','/ Simulation'],
  'port':['⚓','Port Operations','/ Berths & Queue'],
  'cargo':['📦','Cargo Management','/ Tracking'],
  'route':['🧭','Route Optimization','/ AI Routing'],
  'delay':['⏱','Delay Analytics','/ Root Cause'],
  'fuel':['⛽','Fuel Management','/ Consumption'],
  'cost':['💰','Cost Intelligence','/ Profitability'],
  'esg':['🌱','Sustainability','/ ESG & IMO'],
  'scenario':['🔮','Scenario Simulation','/ Impact Analysis'],
  'report':['📑','Reports Center','/ Generate & Export'],
};

const LAZY_INIT={
  'fleet':()=>initFleetCharts(),
  'port':()=>initPortCharts(),
  'cargo':()=>initCargoCharts(),
  'delay':()=>initDelayCharts(),
  'fuel':()=>initFuelCharts(),
  'cost':()=>initCostCharts(),
  'esg':()=>initESGCharts(),
  'scenario':()=>{initScenarioChart();runScenario();},
  'voyage':()=>calcVoyage(),
};
const initialized=new Set(['dashboard']);

document.querySelectorAll('.sb-nav a').forEach(a=>{
  a.addEventListener('click',e=>{
    e.preventDefault();
    const tab=a.dataset.tab;
    document.querySelectorAll('.sb-nav a').forEach(x=>x.classList.remove('active'));
    a.classList.add('active');
    document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
    const sec=document.getElementById('tab-'+tab);if(sec)sec.classList.add('active');
    const meta=TAB_META[tab]||['📊',tab,''];
    document.getElementById('topbar-title').textContent=meta[1];
    document.getElementById('topbar-bc').textContent=meta[2];
    if(!initialized.has(tab)&&LAZY_INIT[tab]){LAZY_INIT[tab]();initialized.add(tab);}
  });
});

function toggleSidebar(){
  const sb=document.getElementById('sidebar');
  sb.classList.toggle('open');
  sb.style.display=sb.style.display==='none'||sb.style.display===''?'flex':'none';
}

function exportReport(){
  alert('📊 Export initiated. In production this would generate a PDF/Excel report.\\n\\nAvailable formats: PDF, Excel, CSV');
}

// ════════════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════════════
window.addEventListener('DOMContentLoaded',()=>{
  const now=new Date();
  document.getElementById('topbar-date').textContent=now.toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});

  // Animate vessel dots
  document.querySelectorAll('.vessel-dot.sailing').forEach((d,i)=>{
    setInterval(()=>{
      const x=(Math.random()-0.5)*1.5;
      const y=(Math.random()-0.5)*1.5;
      const cur=d.style;
      const lx=parseFloat(cur.left||'50');
      const ly=parseFloat(cur.top||'50');
      d.style.left=(lx+x)+'%';
      d.style.top=(ly+y)+'%';
    },2000+i*300);
  });

  initDashboardCharts();

  // Live KPI animation
  setInterval(()=>{
    const el=document.getElementById('last-update');
    if(el)el.textContent='just now';
  },30000);
});
</script>
</body>
</html>
`;

const ShipFlowPage = () => {
  const iframeRef = useRef(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const iframe = iframeRef.current;
    if (iframe) {
      const timer = setTimeout(() => setIsLoaded(true), 600);
      return () => clearTimeout(timer);
    }
  }, []);

  const toggleFullscreen = () => {
    const iframe = iframeRef.current;
    if (!isFullscreen) {
      if (iframe.requestFullscreen) iframe.requestFullscreen();
      else if (iframe.webkitRequestFullscreen) iframe.webkitRequestFullscreen();
    } else {
      if (document.exitFullscreen) document.exitFullscreen();
    }
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0a0e17', color: '#e6edf3', fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      
      {/* Hero Header */}
      <div style={{
        background: 'linear-gradient(135deg, #0d1117 0%, #161b22 50%, #0d1117 100%)',
        borderBottom: '1px solid #21262d',
        padding: '32px 32px 24px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        {/* Decorative glow */}
        <div style={{
          position: 'absolute', top: '-60px', left: '50%', transform: 'translateX(-50%)',
          width: '600px', height: '200px',
          background: 'radial-gradient(ellipse, rgba(59,130,246,0.08) 0%, transparent 70%)',
          pointerEvents: 'none'
        }} />

        <div style={{ maxWidth: '1400px', margin: '0 auto', position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
            <div>
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: '8px',
                background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.25)',
                borderRadius: '20px', padding: '4px 12px', marginBottom: '12px'
              }}>
                <span style={{ fontSize: '11px', color: '#3b82f6', fontWeight: '700', letterSpacing: '0.5px', textTransform: 'uppercase' }}>
                  🚢 Maritime Logistics Intelligence
                </span>
              </div>
              <h1 style={{
                fontSize: '32px', fontWeight: '800', margin: '0 0 6px',
                background: 'linear-gradient(135deg, #3b82f6, #06b6d4)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'
              }}>
                ShipFlow AI v2.0
              </h1>
              <p style={{ fontSize: '14px', color: '#8b949e', margin: 0 }}>
                Maritime Logistics Intelligence Platform — by <strong style={{ color: '#e6edf3' }}>Fastabiq Rahmat Imanu</strong>
              </p>
            </div>

            <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
              {[
                { label: 'Voyage Planning', color: '#3b82f6' },
                { label: 'Port Operations', color: '#22c55e' },
                { label: 'Route Optimization', color: '#a855f7' },
                { label: 'Cost & ESG', color: '#f59e0b' },
              ].map(tag => (
                <span key={tag.label} style={{
                  fontSize: '10px', fontWeight: '700', padding: '3px 9px', borderRadius: '6px',
                  background: tag.color + '18', color: tag.color,
                  border: '1px solid ' + tag.color + '35', letterSpacing: '0.3px', textTransform: 'uppercase'
                }}>{tag.label}</span>
              ))}
            </div>
          </div>

          {/* Stats bar */}
          <div style={{
            display: 'flex', gap: '24px', marginTop: '20px', paddingTop: '20px',
            borderTop: '1px solid #21262d', flexWrap: 'wrap'
          }}>
            {[
              { val: '12', label: 'Dashboard Modules', color: '#f59e0b' },
              { val: '42', label: 'Active Vessels', color: '#3b82f6' },
              { val: '18', label: 'Global Ports', color: '#22c55e' },
              { val: 'Live', label: 'AIS Tracking', color: '#a855f7' },
            ].map(s => (
              <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '22px', fontWeight: '800', color: s.color }}>{s.val}</span>
                <span style={{ fontSize: '11px', color: '#6e7681', lineHeight: '1.3' }}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Dashboard Container */}
      <div style={{ padding: '20px 32px 40px', maxWidth: '1400px', margin: '0 auto' }}>

        {/* Toolbar */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: '12px', flexWrap: 'wrap', gap: '10px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '8px', height: '8px', borderRadius: '50%',
              background: isLoaded ? '#22c55e' : '#3b82f6',
              boxShadow: isLoaded ? '0 0 6px #22c55e' : '0 0 6px #3b82f6',
              transition: 'all 0.3s'
            }} />
            <span style={{ fontSize: '11px', color: '#8b949e' }}>
              {isLoaded ? 'Dashboard loaded & running' : 'Initializing intelligence engine...'}
            </span>
          </div>
          <button
            onClick={toggleFullscreen}
            style={{
              background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.25)',
              color: '#3b82f6', padding: '5px 14px', borderRadius: '6px',
              fontSize: '11.5px', fontWeight: '600', cursor: 'pointer', fontFamily: 'inherit',
              display: 'flex', alignItems: 'center', gap: '5px'
            }}
          >
            ⛶ {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          </button>
        </div>

        {/* iFrame wrapper */}
        <div style={{
          borderRadius: '12px', overflow: 'hidden',
          border: '1px solid #30363d',
          boxShadow: '0 0 0 1px rgba(59,130,246,0.05), 0 24px 60px rgba(0,0,0,0.5)',
          position: 'relative'
        }}>
          {/* Chrome bar */}
          <div style={{
            background: '#161b22', borderBottom: '1px solid #21262d',
            padding: '8px 14px', display: 'flex', alignItems: 'center', gap: '6px'
          }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#ef4444', opacity: 0.8 }} />
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#f59e0b', opacity: 0.8 }} />
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#22c55e', opacity: 0.8 }} />
            <span style={{
              marginLeft: '10px', fontSize: '10.5px', color: '#6e7681',
              fontFamily: 'monospace', flex: 1, textAlign: 'center', paddingRight: '30px'
            }}>
              shipflow — maritime-logistics-platform
            </span>
          </div>

          {!isLoaded && (
            <div style={{
              position: 'absolute', top: '40px', left: 0, right: 0, bottom: 0,
              background: '#0d1117', display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', zIndex: 10, gap: '14px'
            }}>
              <div style={{ fontSize: '32px' }}>🚢</div>
              <div style={{ fontSize: '14px', color: '#3b82f6', fontWeight: '700' }}>Loading ShipFlow AI...</div>
              <div style={{
                width: '200px', height: '3px', background: '#21262d', borderRadius: '2px', overflow: 'hidden'
              }}>
                <div style={{
                  height: '100%', background: 'linear-gradient(90deg, #3b82f6, #06b6d4)',
                  borderRadius: '2px', animation: 'loadbar 0.6s ease-out forwards',
                  width: '0%'
                }} />
              </div>
              <style>{`@keyframes loadbar { to { width: 100% } }`}</style>
            </div>
          )}

          <iframe
            ref={iframeRef}
            srcDoc={SHIPFLOW_HTML}
            title="ShipFlow AI v2.0 - Maritime Logistics Dashboard"
            style={{
              width: '100%',
              height: '88vh',
              border: 'none',
              display: 'block',
              background: '#070d1a'
            }}
            onLoad={() => setIsLoaded(true)}
            sandbox="allow-scripts allow-same-origin allow-forms"
          />
        </div>

        {/* Footer info */}
        <div style={{
          marginTop: '20px', display: 'flex', justifyContent: 'space-between',
          alignItems: 'center', flexWrap: 'wrap', gap: '10px',
          fontSize: '11px', color: '#6e7681'
        }}>
          <span>© 2025 Fastabiq Rahmat Imanu — ShipFlow AI Platform</span>
          <span style={{ fontFamily: 'monospace' }}>v2.0.0 · Maritime Operations · Fleet Intelligence</span>
        </div>
      </div>
    </div>
  );
};

export default ShipFlowPage;